package library

object FiltrageHTML extends FiltrageHtml{
  
  def filtreHtml(h: Html, e: Expression): Boolean = {
    //all content in a set then matches the word
    var res:Boolean = true
    val allWords = gettingAllWords(h)
    //first test only 1 word
    res = res && filtrerWithoutList(e, allWords)
    res
  }
  
  private def filtrerWithoutList(e : Expression, l: Array[String]): Boolean = {
    var res : Boolean = true
      e match {
      case m : Mot =>
        res = l.contains(m.w.trim())
      case ou : Ou =>
        res = res && (filtrerWithoutList(ou.e1, l) || filtrerWithoutList(ou.e2, l))
      case et : Et =>
        res = res && (filtrerWithoutList(et.e1, l) && filtrerWithoutList(et.e2, l))
    }
    res
  }
  
  private def gettingAllWords (h:Html): Array[String] = {
    var temp = Array[String]()
    h match {
      case tag: Tag => 
        tag.children.foreach {
          child => 
          temp = temp++gettingAllWords(child)
       }
       case txt: Texte => 
         temp = temp ++ txt.content.toString().split(" ")
         temp = temp.map(trimPerso)
    }
    temp
  }
  
  private def trimPerso (s:String) : String = {
    s.trim()
  }
  

  }