package library

object FiltrageURL {
  trait FiltrageURLs {
    /**
     * A partir d'un document Html h, rend la liste des URLs accessibles à partir
     * de h (ces URLs sont des hyperliens h) tels que ces URLs sont tous des URLs
     * d'annonces du site de référence
     *
     * @param h le document Html
     * @return la liste des URLs d'annonces contenues dans h
     */
    def filtreAnnonce(h: Html): List[String]
  }

  object FiltrageURLsVivastreet extends FiltrageURLs {
    def filtreAnnonce(h: Html): List[String] = {

      var l: List[String] = List()

      h match {
        case Tag(texte, list, listHTML) => {
          if (texte == "a") {
            for ((element1, element2) <- list) {
              println(element2)
              println(element2.contains("vivastreet.com"))
              if (element2.contains("search.vivastreet.com")) {
                l = l :+ element2
              }
            }
          }
          for (element <- listHTML) {
            l = l ++ filtreAnnonce(element)
          }
        }
        case _ => "false"
      }

      return l
    }
  }

}