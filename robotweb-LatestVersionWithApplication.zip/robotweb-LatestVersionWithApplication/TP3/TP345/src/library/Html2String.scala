package library

object Html2String extends HtmlVersString {

  override def traduire(h: Html): String = {
    traduireRec(h)
  }

  private def traduireRec(h: Html): String = {
    var message: String = ""
    h match {
      case Tag(texte, list, listHtml) => {
        message += s"<$texte"
        for ((element1, element2) <- list) {
          message += s""" $element1"$element2""""
        }
        if (texte == "meta") {
          message += "/"
        }
        message += s">\n"
        for (html <- listHtml) {
          message += traduireRec(html)
        }
        if (texte != "meta")
          message += s"</$texte>"
        message
      }
      case Texte(content) =>
        message += content + "\n"; message
      case _ => ""
    }
  }

}