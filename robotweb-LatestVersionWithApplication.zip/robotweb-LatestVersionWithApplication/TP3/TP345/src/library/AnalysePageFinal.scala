package library

object AnalysePageFinal extends AnalysePage {

  override def resultats(url: String, exp: Expression): List[(String, String)] = {

    var lsolution: List[(String, String)] = List()

    /*etape 1 : recuperation html de l'url*/
    val html: Html = OutilsWebObjet.obtenirHtml(url)

    /*etape 2 : exctraction des annonces de l'html precedent*/
    var lURLs: List[String] = FiltrageURL.FiltrageURLsVivastreet.filtreAnnonce(html)

    /*etape 3 : recuperation des documents html de la liste lURLs*/
    var lHTML: List[Html] = List()
    for (u <- lURLs) {
      println("etape 3 allez on y croit")
      lHTML = lHTML :+ OutilsWebObjet.obtenirHtml(u)
    }
    println("J'ai fini étpae 3")

    /*etape 4 : creation des couples url,html valides*/
    var lCoupleUrlHtml: List[(String, Html)] = List()
    if (lHTML.size != 0) {
      for (x <- 0 to lHTML.size - 1) {
        if (FiltrageHTML.filtreHtml(lHTML(x), exp)) {
          lCoupleUrlHtml = lCoupleUrlHtml :+ (lURLs(x), lHTML(x))
        }
      }
    }
    println("J'ai fini étpae 4")
    /*etape 5 : creation des couples titres,html*/

    for (couple <- lCoupleUrlHtml) {
      println("???????????????????????,")

      lsolution = lsolution :+ (getTitle(couple._2), couple._1)
    }
    println("J'ai fini étpae 5")
    return lsolution;
  }

  private def getTitle(html: Html): String = {

    var result: String = ""

    html match {
      case t: Tag => {
        if (t.name == "title") {
          t.children match {
            case List(Texte(x)) => return x
            case _              => print("non")
          }
        } else {
          t.children.foreach {
            child =>
              getTitle(child)
          }
        }
      }
      case _ => "false"
    }

    return result
  }
}