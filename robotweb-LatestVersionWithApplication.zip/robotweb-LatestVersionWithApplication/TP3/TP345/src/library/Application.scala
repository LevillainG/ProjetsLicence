package library

import java.io._
object Application extends App {
  /**
   * write a `String` to the `filename`.
   */
  def writeFile(filename: String, s: String): Unit = {
    val file = new File(filename)
    val bw = new BufferedWriter(new FileWriter(file))
    bw.write(s)
    bw.close()
  }

  def createFiles: Unit = {
    val exp: Expression = ParserExpression.lireExpression
    val req: String = "https://search.vivastreet.com/annonces/fr?lb=new&search=1&start_field=1&keywords=" + createURL(exp) + "&cat_1=&geosearch_text=&searchGeoId="
    print(req)
    val l: List[(String, String)] = AnalysePageFinal.resultats(req, exp)
    /**
     * pb titre
     */
    val h: Html = ProducteurHtml.resultatVersHtml(l)
    val nomFichier: String = "pageHtml.html"
    writeFile(nomFichier, Html2String.traduire(h))
  }

  def createURL(e: Expression): String = {
    var exp: String = ""
    e match {
      case m: Mot =>
        exp = exp + m.w.trim()
      case ou: Ou =>
        exp = exp + (createURL(ou.e1) + "+" + createURL(ou.e2))
      case et: Et =>
        exp = exp + (createURL(et.e1) + "&" + createURL(et.e2))
    }
    exp
  }

  createFiles
}