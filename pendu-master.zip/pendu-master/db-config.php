<?php
	$DB_DSN = 'mysql:host=localhost;dbname=pendunet';
	$DB_USER = 'root';
	$DB_PASS = '';
?>
