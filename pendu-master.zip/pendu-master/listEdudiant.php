<?php
    require 'db-config.php';
	
	try {
		$options = [
			PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
		];
		
		$PDO = new PDO($DB_DSN, $DB_USER, $DB_PASS);
		echo "Connexion établie !";
		
		$sql = 'select * from etudiant';
		$result = $PDO->query($sql);
		$list_etudiant = $result->fetchAll(PDO::FETCH_ASSOC);
		$result->closeCursor();

        echo 
			'<table>
				<thead>
					<tr>
						<td>Nom</td>
						<td>Prénom</td>
						<td>Ecole</td>
						<td>Classe</td>
					</tr>
				</thead>
				<tbody>'
					foreach ($list_etudiant as $etudiant){
						echo '<tr>'
						for ($i=0; $i<4; $i++) {
							echo '<td>'.$etudiant['nom'].'</td>'
							echo '<td>'.$etudiant['prenom'].'</td>'
							echo '<td>'.$etudiant['ecole'].'</td>'
							echo '<td>'.$etudiant['classe'].'</td>'
						}
						echo '</tr>'
					}
        echo '	</tbody>
			</table>'
        
	} catch(PDOException $pe) {
		echo 'ERREUR : '.$pe->getMessage();
	}
?>
