<?php
	require 'db-config.php';
	
	try {
		$options = [
			PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
		];
		
		$PDO = new PDO($DB_DSN, $DB_USER, $DB_PASS);
		echo "Connexion établie !";
		
		$sql = 'select * from etudiant';
		$result = $PDO->query($sql);
		$list_etudiant = $result->fetchAll(PDO::FETCH_ASSOC);
		$result->closeCursor();
	} catch(PDOException $pe) {
		echo 'ERREUR : '.$pe->getMessage();
	}
	
	if (isset($_POST['id']) && isset($_POST['pwd'])) {
		
		foreach ($list_etudiant as $etudiant){
			if ($etudiant['login']==$_POST['id'] && $etudiant['password']==$_POST['pwd']) {
				session_start();
				$_SESSION['CONNECT'] = 'OK';
				$_SESSION['ID'] = $_POST['id'];
				$_SESSION['PWD'] = $_POST['pwd'];
				$url = 'compte.html';
				header('Location:'.$url);
				exit;
			}
		}
		if (empty($_POST['id']) || empty($_POST['pwd'])) {
			$url = 'Accueil.html'.'?status=Error1&pId=formAError';
			header('Location:'.$url);
			exit;
		} else {
			$url = 'Accueil.html'.'?status=Error2&pId=formAError';
			header('Location:'.$url);
			exit;
		}
	} elseif (isset($_GET['afaire']) && $_GET['afaire']=="deconnexion") {
		session_start();
		session_unset();
		session_destroy();
		session_write_close();
		$url = 'login.php'.'?status=Error3&pId=formAError';
		header('Location:'.$url);
		exit;
	}
?>
