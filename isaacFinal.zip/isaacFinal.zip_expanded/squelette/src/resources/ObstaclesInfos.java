package resources;

import libraries.Vector2;

public class ObstaclesInfos {

	public static Vector2 ROCK_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.7);
	public static Vector2 SPIKES_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.7);
	
}
