package resources;

import libraries.Vector2;

public class EnemyInfos {
	//BasicEnemies
	public static Vector2 SPIDER_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.4);
	public static final double SPIDER_SPEED = 0.006;
	
	public static Vector2 FLY_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.4);
	public static final double FLY_SPEED = 0.003;
	
	public static Vector2 BALL_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.1);
	public static final double BALL_SPEED = 0.007;

	public static final int FLY_HEALTH = 3;
	public static final int SPIDER_HEALTH = 5;
	
	//Boss
	public static final double BOSS_SPEED = 0.005;
	public static Vector2 BOSS_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.7);
}
