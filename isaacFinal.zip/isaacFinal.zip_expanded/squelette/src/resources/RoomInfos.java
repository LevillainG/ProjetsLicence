package resources;

import gameWorld.Room;
import libraries.Vector2;

public class RoomInfos
{
	public static enum DoorDirections {
		NORTH, WEST, SOUTH, EAST;
	}
	
	public static final int NB_TILES = 9;
	public static final double TILE_WIDTH = 1.0 / NB_TILES;
	public static final double TILE_HEIGHT = 1.0 / NB_TILES;
	public static final Vector2 TILE_SIZE = new Vector2(TILE_WIDTH, TILE_HEIGHT);
	public static final Vector2 HALF_TILE_SIZE = new Vector2(TILE_WIDTH, TILE_HEIGHT).scalarMultiplication(0.5);
	
	public static final Vector2 POSITION_CENTER_OF_ROOM = new Vector2(0.5, 0.5);
	
	public static final int MAX_MOB = 5;
	public static final int MIN_MOB = 2;
	
	public static final int MAX_OBSTACLES = 4;
	public static final int MIN_OBSTACLES = 2;
	
	public static final int MAX_TRAPS = 3;
	public static final int MIN_TRAPS = 2;
	
	public static final Vector2 ITEM_SIZE = TILE_SIZE.scalarMultiplication(0.4);
	
	public static final Vector2 BOSS_ROCK_NORTH = Room.positionFromTileIndex(NB_TILES/2, NB_TILES-3);
	public static final Vector2 BOSS_ROCK_SOUTH = Room.positionFromTileIndex(NB_TILES/2, 2);
	public static final Vector2 BOSS_ROCK_WEST = Room.positionFromTileIndex(2, NB_TILES/2);
	public static final Vector2 BOSS_ROCK_EAST = Room.positionFromTileIndex(NB_TILES-3, NB_TILES/2);
}
