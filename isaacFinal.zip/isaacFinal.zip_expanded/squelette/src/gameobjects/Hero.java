package gameobjects;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import gameWorld.Door;
import gameWorld.Room;
import gameWorld.Wall;
import libraries.Physics;
import libraries.StdDraw;
import libraries.Vector2;
import resources.HeroInfos;
import resources.ImagePaths;
import resources.RoomInfos;

public class Hero
{
	private Vector2 position;
	private Vector2 size;
	private String imagePath;
	private double speed;
	private Vector2 direction;
	private Room currentRoom;
	
	
	private Tear tear;
	private int damage;
	private int attackSpeed;	//Not used in the game (i'm using another method)
	private int health;
	private int maxHealth;
	private int money;
	private int maxMoney;
	
	private boolean invicible;
	private boolean godMode;
	private int invincibleCounter;

	public Hero(Vector2 position, Vector2 size, double speed, String imagePath)
	{
		this.position = position;
		this.size = size;
		this.speed = speed;
		this.imagePath = imagePath;
		this.direction = new Vector2();
		this.tear = new Tear(position);
		this.health = 6;
		this.maxHealth = 6;
		this.money = 0;
		this.maxMoney = 20;
		this.godMode = false;
		this.damage = 1;
	}

	public void updateGameObject()
	
	{	
		invicibilityCheck();
		move();
		tear.updateGameObject();
	}

	private void move()
	{
		Vector2 normalizedDirection = getNormalizedDirection();
		Vector2 positionAfterMoving = getPosition().addVector(normalizedDirection);
		if(!currentRoom.getForbiddenTiles().equals(null)) {
			for(Vector2 position : currentRoom.getForbiddenTiles()) {
				if(positionAfterMoving.distance(position) < HeroInfos.ISAAC_SIZE.getX() * 1.15 | positionAfterMoving.distance(position) < HeroInfos.ISAAC_SIZE.getY() * 1.15) {
					setNullDirection();
					normalizedDirection = getNormalizedDirection();
					positionAfterMoving = getPosition().addVector(normalizedDirection);
				}
			}
		}
		setPosition(positionAfterMoving);
		if(!tear.isShot()) {
			tear.setPosition(positionAfterMoving);
		}
		direction = new Vector2();
	}
	
	/*
	 * Manage the invincibility when hit
	 */
	private void invicibilityCheck() {
		if(isInvicible()) {
			if(getInvincibleCounter() > 0) {
				setInvincibleCounter(invincibleCounter-1);
			}
			else {
				setInvicible(false);
			}
		}
	}
	/*
	 * Set the health of the player
	 */
	public void setHealth(int health) {
		if(!isInvicible()) {
			this.health = health;
			setInvicible(true);
			setInvincibleCounter(30); //Cycle count
		}
	}
	
	
	/*
	 * method that draw the amount of money the player has
	 */
	private void drawMoney() {
		Vector2 positionCoin = Room.positionFromTileIndex(0, 0);
		StdDraw.picture(positionCoin.getX() , positionCoin.getY(), ImagePaths.COIN, RoomInfos.ITEM_SIZE.getX(), RoomInfos.ITEM_SIZE.getX(),
				0);
		Vector2 positionText = positionCoin;
		positionText.addX(0.05);
		StdDraw.setPenColor(255,255,255);
		String moneyString = "" + getMoney();
		StdDraw.textRight(positionText.getX(), positionText.getY(), moneyString);
	}
	
	
	/*
	 * method that draw the healthbar
	 */
	private void drawHealth() {
		Vector2 previousPosition = Room.positionFromTileIndex(0, RoomInfos.NB_TILES-1);
		if(health%2 == 0) {
			for(int i = 0; i < health; i+=2) {
				Vector2 position = previousPosition;
				position.addX(0.04);
				StdDraw.picture(position.getX() , position.getY(), ImagePaths.HEART_HUD, HeroInfos.HEART_SIZE.getX(), HeroInfos.HEART_SIZE.getX(),
						0);
			}
		}
		else {
			int compteur = 0;
			while(compteur < health) {
				Vector2 position = previousPosition;
				position.addX(0.04);
				if(compteur+2 < health) {
					StdDraw.picture(position.getX() , position.getY(), ImagePaths.HEART_HUD, HeroInfos.HEART_SIZE.getX(), HeroInfos.HEART_SIZE.getX(),
							0);
					compteur+=2;
				}
				else {
					StdDraw.picture(position.getX() , position.getY(), ImagePaths.HALF_HEART_HUD, HeroInfos.HEART_SIZE.getX(), HeroInfos.HEART_SIZE.getX(),
							0);
					compteur+=1;
				}
			}
		}
	}

	public void drawGameObject()
	{
		drawHealth();
		drawMoney();
		if(!isInvicible()) {
			StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
					0);
		}
		else {	//Blinking effect when hit
			if(getInvincibleCounter()%2 != 0) {
				StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
						0);
			}
		}
	}



	/*
	 * Moving from key inputs. Direction vector is later normalised.
	 */
	public void goUpNext()
	{
		getDirection().addY(1);
	}

	public void goDownNext()
	{
		getDirection().addY(-1);
	}

	public void goLeftNext()
	{
		getDirection().addX(-1);
	}

	public void goRightNext()
	{
		getDirection().addX(1);
	}

	/*
	 * Add direction to the tear from key inputs
	 */
	public void shootUpNext() 
	{
		if(!tear.isShot()) {
			tear.setShot(true);
			tear.setShootDirection("Up");
		}
	}

	public void shootDownNext() 
	{
		if(!tear.isShot()) {
			tear.setShot(true);
			tear.setShootDirection("Down");
		}
	}

	public void shootRightNext() 
	{
		if(!tear.isShot()) {
			tear.setShot(true);
			tear.setShootDirection("Right");
		}
	}

	public void shootLeftNext() 
	{
		if(!tear.isShot()) {
			tear.setShot(true);
			tear.setShootDirection("Left");
		}
	}


	public Vector2 getNormalizedDirection()
	{
		Vector2 normalizedVector = new Vector2(direction);
		normalizedVector.euclidianNormalize(speed);
		return normalizedVector;
	}

	public void setNullDirection() {
		direction.setX(0);
		direction.setY(0);
	}

	/*
	 * Getters and Setters
	 */

	public Vector2 getPosition()
	{
		return position;
	} 
	public void setPosition(Vector2 position)
	{
		this.position = position;
	}

	public Vector2 getSize()
	{
		return size;
	}

	public void setSize(Vector2 size)
	{
		this.size = size;
	}

	public String getImagePath()
	{
		return imagePath;
	}

	public void setImagePath(String imagePath)
	{
		this.imagePath = imagePath;
	}

	public double getSpeed()
	{
		return speed;
	}

	public void setSpeed(double speed)
	{
		this.speed = speed;
	}

	public Vector2 getDirection()
	{
		return direction;
	}

	public void setDirection(Vector2 direction)
	{
		this.direction = direction;
	}

	public Room getCurrentRoom() {
		return currentRoom;
	}

	public void setCurrentRoom(Room currentRoom) {
		this.currentRoom = currentRoom;
	}

	public Tear getTears() {
		return tear;
	}

	public void setTears(Tear tear) {
		this.tear = tear;
	}

	public int getHealth() {
		return health;
	}


	public boolean isInvicible() {
		return invicible;
	}

	public void setInvicible(boolean invicible) {
		this.invicible = invicible;
	}

	public int getInvincibleCounter() {
		return invincibleCounter;
	}

	public void setInvincibleCounter(int invincibleCounter) {
		this.invincibleCounter = invincibleCounter;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public int getMaxHealth() {
		return maxHealth;
	}

	public void setMaxHealth(int maxHealth) {
		this.maxHealth = maxHealth;
	}

	public int getMaxMoney() {
		return maxMoney;
	}

	public void setMaxMoney(int maxMoney) {
		this.maxMoney = maxMoney;
	}

	public boolean isGodMode() {
		return godMode;
	}

	public void setGodMode(boolean godMode) {
		this.godMode = godMode;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}
	
	
	
	

}
