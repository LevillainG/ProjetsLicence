package gameobjects;

import libraries.Vector2;
import resources.ImagePaths;
import resources.RoomInfos;

public class HalfHeart extends Item{

	public HalfHeart(Vector2 position) {
		super(position, RoomInfos.ITEM_SIZE, ImagePaths.HALF_HEART_PICKABLE, 1);
	}

}
