package gameobjects;

import libraries.Vector2;
import resources.ImagePaths;

public class Penny extends Coin{

	public Penny(Vector2 position) {
		super(position, ImagePaths.COIN, 1);
		// TODO Auto-generated constructor stub
	}

}
