package gameobjects;

import libraries.StdDraw;
import libraries.Vector2;

public abstract class Item {

	private Vector2 position;
	private Vector2 size;
	private String imagePath;
	private int value;
	private boolean collected;
	private boolean priced;
	private int price;
	
	public Item(Vector2 position, Vector2 size, String imagePath, int value) {
		this.position = position;
		this.size = size;
		this.imagePath = imagePath;
		this.value = value;
		this.collected = false;
		this.priced = false;
		this.price = 0;
	}
	
	
	public void drawGameObject()
	{
		StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
				0);
	}

	
	//Getters & Setters

	public Vector2 getPosition() {
		return position;
	}


	public void setPosition(Vector2 position) {
		this.position = position;
	}


	public Vector2 getSize() {
		return size;
	}


	public void setSize(Vector2 size) {
		this.size = size;
	}


	public String getImagePath() {
		return imagePath;
	}


	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}


	public int getValue() {
		return value;
	}


	public void setValue(int value) {
		this.value = value;
	}


	public boolean isCollected() {
		return collected;
	}


	public void setCollected(boolean collected) {
		this.collected = collected;
	}


	public boolean isPriced() {
		return priced;
	}


	public void setPriced(boolean priced) {
		this.priced = priced;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
	
}
