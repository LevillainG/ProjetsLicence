package gameobjects;

import java.util.Random;

import gameWorld.Room;
import libraries.StdDraw;
import libraries.Vector2;
import resources.EnemyInfos;
import resources.HeroInfos;

public abstract class BasicEnemy {

	private Vector2 position;
	private Vector2 size;
	private String imagePath;
	private double speed;
	private Vector2 direction;
	private Hero target;
	private Room currentRoom;
	private Ball ball;
	private int health;

	public BasicEnemy(Vector2 position, Vector2 size, double speed, Hero target, String imagePath, Room currentRoom, int health) {
		this.position = position;
		this.size = size;
		this.speed = speed;
		this.imagePath = imagePath;
		this.direction = new Vector2();
		this.target = target;
		this.currentRoom = currentRoom;
		if(this instanceof Fly) {
			this.ball = new Ball(position);
		}
		this.health = health;
	}

	public void updateGameObject()
	{
		moveSet(target.getPosition());
		if(this instanceof Fly) {
			getBall().updateGameObject();
			}
	}

	/**
	 * Move the monster towards the player
	 * @param playerPosition
	 */
	private void moveSet(Vector2 playerPosition) {
		if(this instanceof Spider) {
			if(isInRange(position, playerPosition)) {
				direction = playerPosition.subVector(position);
				Vector2 normalizedDirection = getNormalizedDirection();
				Vector2 positionAfterMoving = getPosition().addVector(normalizedDirection);

				if(!currentRoom.getForbiddenTiles().equals(null)) {
					for(Vector2 position : currentRoom.getForbiddenTiles()) {
						if(positionAfterMoving.distance(position) < EnemyInfos.SPIDER_SIZE.getX() | positionAfterMoving.distance(position) < EnemyInfos.SPIDER_SIZE.getY()) {
							setNullDirection();
							normalizedDirection = getNormalizedDirection();
							positionAfterMoving = getPosition().addVector(normalizedDirection);
						}
					}
				}
				setPosition(positionAfterMoving);
				if(getPosition().distance(getTarget().getPosition()) < 0.01) {
					target.setHealth(target.getHealth()-1);
				}
				direction = new Vector2();
			}
			else {
				randomMovement();
			}
		}

		if(this instanceof Fly) {
			if(isInRange(position, playerPosition)) {
				direction = playerPosition.subVector(position);
				Vector2 normalizedDirection = getNormalizedDirection();
				Vector2 positionAfterMoving = getPosition().addVector(normalizedDirection);	
				setPosition(positionAfterMoving);
				
				if(getPosition().distance(getTarget().getPosition()) < 0.01) {
					target.setHealth(target.getHealth()-1);
				}
				
				getBall().setTarget(playerPosition);
				if(!getBall().isShot()) {
				shootBall(playerPosition);
				}
				else if(getBall().getPosition().distance(getBall().getTarget()) < 0.01) {
					target.setHealth(target.getHealth()-1);
					ball = null;
					setBall(new Ball(getPosition()));
				}
				direction = new Vector2();
			}
			else {
				randomMovement();
			}
		}

	}

	private boolean isInRange(Vector2 position, Vector2 playerPosition) {
		boolean condition = position.distance(playerPosition) != 0.2;
		return condition;
	}

	/*
	 * Projectiles for the Fly
	 */
	private void shootBall(Vector2 playerPosition) {
		if(getBall() != null) {
			Vector2 target = new Vector2(playerPosition);
			getBall().setTarget(target);
			getBall().setShot(true);
		}
	}

	/**
	 * Generate a random number and choose a direction
	 */
	private void randomMovement() {
		Random ran = new Random();
		int numero = ran.nextInt(3);
		if(numero == 0) {
			getDirection().addY(1);
		}
		if(numero == 1) {
			getDirection().addY(-1);
		}
		if(numero == 2) {
			getDirection().addX(1);
		}
		if(numero == 3) {
			getDirection().addX(-1);
		}


	}


	public void drawGameObject()
	{
		StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
				0);
	}

	public Vector2 getNormalizedDirection()
	{
		Vector2 normalizedVector = new Vector2(direction);
		normalizedVector.euclidianNormalize(speed);
		return normalizedVector;
	}


	//Getters and Setters

	public Vector2 getPosition() {
		return position;
	}

	public void setPosition(Vector2 position) {
		this.position = position;
	}

	public void setNullDirection() {
		direction.setX(0);
		direction.setY(0);
	}
	public Vector2 getSize() {
		return size;
	}

	public void setSize(Vector2 size) {
		this.size = size;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public Vector2 getDirection() {
		return direction;
	}

	public void setDirection(Vector2 direction) {
		this.direction = direction;
	}

	public Hero getTarget() {
		return target;
	}

	public void setTarget(Hero target) {
		this.target = target;
	}

	public Room getCurrentRoom() {
		return currentRoom;
	}

	public void setCurrentRoom(Room currentRoom) {
		this.currentRoom = currentRoom;
	}

	public Ball getBall() {
		return ball;
	}

	public void setBall(Ball ball) {
		this.ball = ball;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}
	
	

}
