package gameobjects;

import libraries.Vector2;
import resources.ImagePaths;
import resources.RoomInfos;

public class BloodOfTheMartyr extends Item{

	public BloodOfTheMartyr(Vector2 position) {
		super(position, RoomInfos.ITEM_SIZE, ImagePaths.BLOOD_OF_THE_MARTYR, 1);
		// TODO Auto-generated constructor stub
	}

}
