package gameobjects;

import libraries.Vector2;
import resources.ImagePaths;

public class Dime extends Coin{

	public Dime(Vector2 position) {
		super(position, ImagePaths.DIME, 10);
		// TODO Auto-generated constructor stub
	}

}
