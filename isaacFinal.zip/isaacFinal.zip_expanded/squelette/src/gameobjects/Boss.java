package gameobjects;

import java.util.Random;

import gameWorld.Room;
import libraries.StdDraw;
import libraries.Vector2;
import resources.EnemyInfos;
import resources.HeroInfos;
import resources.ImagePaths;
import resources.RoomInfos;

public class Boss {

	//Attributes relative to the position and creation of the object
	private Vector2 position;
	private Vector2 size;
	private String imagePath;
	private double speed;
	private Vector2 direction;

	//Attributes relative to the information the object needs
	private Hero target;
	private Room currentRoom;
	private Ball ball;
	private int health;
	private boolean attacking;
	private boolean invincible;
	private int invincibleCounter;
	private int attackCounter;
	private String attackType;
	private boolean alive;

	public Boss(Vector2 position, Room currentRoom, Hero target) {
		this.position = position;
		this.currentRoom = currentRoom;
		this.target = target;
		this.size = EnemyInfos.BOSS_SIZE;
		this.speed = EnemyInfos.BOSS_SPEED;
		this.imagePath = ImagePaths.MAGDALENE;
		this.ball = new Ball(position);
		this.health = 15;
		this.direction= new Vector2();
		this.attacking = false;
		this.attackType = "None";
		this.invincible = false;
		this.alive = true;
	}

	public void updateGameObject() {
		replaceBall();
		healthManager();
		moveSet(target.getPosition());
		getBall().updateGameObject();
	}

	private void moveSet(Vector2 playerPosition) {
		if(isAttacking()) {
			setAttackCounter(attackCounter-1);
			if(attackType.equals("distance")) {
				distance(playerPosition);
			}
			if(attackType.equals("cac")) {
				cac(playerPosition);
			}
			if(attackCounter<0) {
				setAttacking(false);
				setAttackType("None");
			}
		}
		else {							//Choose a movest randomly
			setAttackCounter(30);
			Random ran = new Random();
			int random = ran.nextInt(2);

			if(random == 0) {
				cac(playerPosition);
			}
			if(random == 1) {
				distance(playerPosition);
			}
		}
	}
	//Move the boss close to the target
	private void cac(Vector2 playerPosition) {
		this.attackType = "cac";
		direction = playerPosition.subVector(position);
		Vector2 normalizedDirection = getNormalizedDirection();
		Vector2 positionAfterMoving = getPosition().addVector(normalizedDirection);
		setPosition(positionAfterMoving);
		setAttacking(true);

		if(getPosition().distance(getTarget().getPosition()) < 0.01) {
			target.setHealth(target.getHealth()-2);
		}
	}
	//The boss shoots a ball
	private void distance(Vector2 playerPosition) {
		this.attackType = "distance";
		setAttacking(true);
		getBall().setTarget(playerPosition);
		if(!getBall().isShot()) {
			shootBall(playerPosition);
		}
		else if(getBall().getPosition().distance(getBall().getTarget()) < 0.01) {
			target.setHealth(target.getHealth()-1);
			ball = null;
			setBall(new Ball(getPosition()));
		}
	}
	//Shoot the ball
	private void shootBall(Vector2 playerPosition) {
		if(getBall() != null) {
			Vector2 target = new Vector2(playerPosition);
			getBall().setTarget(target);
			getBall().setShot(true);
		}
	}
	
	//Method to replace the ball on the pos of the boss
	private void replaceBall() {
		if(!getBall().isShot()) {
			getBall().setPosition(getPosition());
		}
	}

	//Now, manage the health of the boss
	private void healthManager() {
		if(isInvincible()) {
			if(getInvincibleCounter() <= 0) {
				setInvincible(false);
			}
			else {
				setInvincibleCounter(getInvincibleCounter()-1);
			}

		}
		if(getTarget().getTears().getPosition().distance(getPosition()) < RoomInfos.HALF_TILE_SIZE.euclidianNorm()
				&& getTarget().getTears().isShot()) {
			System.out.println("hit");
			getTarget().setTears(new Tear(getTarget().getPosition()));
			setHealth(health-getTarget().getDamage());
		}
		if(health <= 0) {
			setAlive(false);
		}
	}

	public void drawGameObject()
	{
		if(!isInvincible()) {
			StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
					0);
		}
		else {
			if(getInvincibleCounter()%2 != 0) {
				StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
						0);
			}
		}
	}

	public Vector2 getNormalizedDirection()
	{
		Vector2 normalizedVector = new Vector2(direction);
		normalizedVector.euclidianNormalize(speed);
		return normalizedVector;
	}

	//Getters & Setters

	public Vector2 getPosition() {
		return position;
	}

	public void setPosition(Vector2 position) {
		this.position = position;
	}

	public Vector2 getSize() {
		return size;
	}

	public void setSize(Vector2 size) {
		this.size = size;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public Vector2 getDirection() {
		return direction;
	}

	public void setDirection(Vector2 direction) {
		this.direction = direction;
	}

	public Hero getTarget() {
		return target;
	}

	public void setTarget(Hero target) {
		this.target = target;
	}

	public Room getCurrentRoom() {
		return currentRoom;
	}

	public void setCurrentRoom(Room currentRoom) {
		this.currentRoom = currentRoom;
	}

	public Ball getBall() {
		return ball;
	}

	public void setBall(Ball ball) {
		this.ball = ball;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		if(!isInvincible()) {
			this.health = health;
			setInvincible(true);
			setInvincibleCounter(50);
		}
	}

	public boolean isAttacking() {
		return attacking;
	}

	public void setAttacking(boolean attacking) {
		this.attacking = attacking;
	}

	public void setAttackCounter(int attackCounter) {
		this.attackCounter = attackCounter;
	}

	public String getAttackType() {
		return attackType;
	}

	public void setAttackType(String attackType) {
		this.attackType = attackType;
	}

	public int getAttackCounter() {
		return attackCounter;
	}

	public boolean isAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
	}

	public boolean isInvincible() {
		return invincible;
	}

	public void setInvincible(boolean invincible) {
		this.invincible = invincible;
	}

	public int getInvincibleCounter() {
		return invincibleCounter;
	}

	public void setInvincibleCounter(int invincibleCounter) {
		this.invincibleCounter = invincibleCounter;
	}

}
