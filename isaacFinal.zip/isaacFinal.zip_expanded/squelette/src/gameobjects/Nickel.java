package gameobjects;

import libraries.Vector2;
import resources.ImagePaths;

public class Nickel extends Coin{

	public Nickel(Vector2 position) {
		super(position, ImagePaths.NICKEL, 5);
		// TODO Auto-generated constructor stub
	}

}
