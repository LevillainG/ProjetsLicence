package gameobjects;

import libraries.StdDraw;
import libraries.Vector2;
import resources.EnemyInfos;
import resources.HeroInfos;
import resources.ImagePaths;

public class Ball {
	private Vector2 size;
	private Vector2 position;
	private Vector2 direction;
	private double speed;
	String imagePath;
	private boolean isShot;
	private boolean collide;
	private Vector2 target;


	public Ball (Vector2 position) {
		this.size = EnemyInfos.BALL_SIZE;
		this.position = position;
		this.imagePath = ImagePaths.TEAR;
		this.speed = EnemyInfos.BALL_SPEED;
		this.direction = new Vector2();
		this.isShot = false;
	}

	public void updateGameObject() {
		move();
	}

	public void move() {

		if(target != null) {
			direction = target.subVector(position);
			Vector2 normalizedDirection = getNormalizedDirection();
			Vector2 positionAfterMoving = getPosition().addVector(normalizedDirection);	
			setPosition(positionAfterMoving);
			direction = new Vector2();
		}

	}


	public void drawGameObject()
	{
		StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
				0);
	}

	public Vector2 getNormalizedDirection()
	{
		Vector2 normalizedVector = new Vector2(direction);
		normalizedVector.euclidianNormalize(speed);
		return normalizedVector;
	}

	/*
	 * Getters & Setters
	 */
	public Vector2 getSize() {
		return size;
	}

	public void setSize(Vector2 size) {
		this.size = size;
	}

	public Vector2 getPosition() {
		return position;
	}

	public void setPosition(Vector2 position) {
		this.position = position;
	}

	public Vector2 getDirection() {
		return direction;
	}

	public void setDirection(Vector2 direction) {
		this.direction = direction;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}


	public boolean isShot() {
		return isShot;
	}


	public void setShot(boolean isShot) {
		this.isShot = isShot;
	}

	public boolean isCollide() {
		return collide;
	}

	public void setCollide(boolean collide) {
		this.collide = collide;
	}

	public Vector2 getTarget() {
		return target;
	}

	public void setTarget(Vector2 target) {
		this.target = target;
	}


}
