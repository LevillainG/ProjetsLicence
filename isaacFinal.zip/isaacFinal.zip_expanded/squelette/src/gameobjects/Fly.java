package gameobjects;

import gameWorld.Room;
import libraries.Vector2;
import resources.EnemyInfos;
import resources.ImagePaths;

public class Fly extends BasicEnemy {
	
	private Ball ball;

	public Fly(Vector2 position,  Hero target, Room room) {
		super(position, EnemyInfos.FLY_SIZE, EnemyInfos.FLY_SPEED, target,  ImagePaths.FLY, room, EnemyInfos.FLY_HEALTH);
		this.ball = new Ball(position);
	}
	
	public Ball getBall() {
		return ball;
	}

	public void setBall(Ball ball) {
		this.ball = ball;
	}

	
	
}
