package gameobjects;

import libraries.Vector2;
import resources.ImagePaths;
import resources.RoomInfos;

public class HpUp extends Item{

	public HpUp(Vector2 position) {
		super(position, RoomInfos.ITEM_SIZE, ImagePaths.HP_UP, 2);
		// TODO Auto-generated constructor stub
	}

}
