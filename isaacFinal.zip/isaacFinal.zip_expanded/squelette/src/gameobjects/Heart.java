package gameobjects;

import libraries.Vector2;
import resources.ImagePaths;
import resources.RoomInfos;

public class Heart extends Item{

	public Heart(Vector2 position) {
		super(position, RoomInfos.ITEM_SIZE, ImagePaths.HEART_PICKABLE, 2);
	}

}
