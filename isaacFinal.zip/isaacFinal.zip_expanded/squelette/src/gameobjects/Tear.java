package gameobjects;

import gameWorld.Room;
import libraries.StdDraw;
import libraries.Vector2;
import resources.HeroInfos;
import resources.ImagePaths;

public class Tear {

	private Vector2 size;
	private Vector2 position;
	private Vector2 direction;
	private double speed;
	String imagePath;
	private boolean isShot;
	private boolean collide;
	private String shootDirection= null;


	public Tear (Vector2 position) {
		this.size = HeroInfos.TEAR_SIZE;
		this.position = position;
		this.imagePath = ImagePaths.TEAR;
		this.speed = HeroInfos.TEAR_SPEED;
		this.direction = new Vector2();
	}


	public void updateGameObject() {
		move();
	}

	public void move() {
		if(shootDirection != null) {
			if(shootDirection.equals("Up")) {
				shootUp();
			}
			else if(shootDirection.equals("Down")) {
				shootDown();
			}
			else if(shootDirection.equals("Right")) {
				shootRight();
			}
			else if(shootDirection.equals("Left")) {
				shootLeft();
			}
		}
		Vector2 normalizedDirection = getNormalizedDirection();
		Vector2 positionAfterMoving = getPosition().addVector(normalizedDirection);
		setPosition(positionAfterMoving);
		direction = new Vector2();
	}

	/*
	 * Goes in a straight line when shot
	 */
	public void shootUp () {
		if(!collide) {
			getDirection().addY(1);
		}
	}

	public void shootDown () {
		if(!collide) {
			getDirection().addY(-1);
		}
	}

	public void shootRight () {
		if(!collide) {
			getDirection().addX(1);
		}
	}

	public void shootLeft () {
		if(!collide) {
			getDirection().addX(-1);
		}
	}



	public void drawGameObject()
	{
		StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
				0);
	}

	public Vector2 getNormalizedDirection()
	{
		Vector2 normalizedVector = new Vector2(direction);
		normalizedVector.euclidianNormalize(speed);
		return normalizedVector;
	}

	/*
	 * Getters & Setters
	 */
	public Vector2 getSize() {
		return size;
	}

	public void setSize(Vector2 size) {
		this.size = size;
	}

	public Vector2 getPosition() {
		return position;
	}

	public void setPosition(Vector2 position) {
		this.position = position;
	}

	public Vector2 getDirection() {
		return direction;
	}

	public void setDirection(Vector2 direction) {
		this.direction = direction;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}


	public boolean isShot() {
		return isShot;
	}


	public void setShot(boolean isShot) {
		this.isShot = isShot;
	}

	public boolean isCollide() {
		return collide;
	}

	public void setCollide(boolean collide) {
		this.collide = collide;
	}


	public String getShootDirection() {
		return shootDirection;
	}


	public void setShootDirection(String shootDirection) {
		this.shootDirection = shootDirection;
	}



}
