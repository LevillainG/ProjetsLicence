package gameobjects;

import gameWorld.Room;
import libraries.Vector2;
import resources.EnemyInfos;
import resources.ImagePaths;

public class Spider extends BasicEnemy{
	
	public Spider(Vector2 position, Hero target, Room room) {
		super(position, EnemyInfos.SPIDER_SIZE, EnemyInfos.SPIDER_SPEED, target,  ImagePaths.SPIDER, room, EnemyInfos.SPIDER_HEALTH);
	}
	

}
