package gameobjects;

import libraries.Vector2;
import resources.RoomInfos;

public abstract class Coin extends Item {
	
	private Vector2 position;
	private int value;
	private String imagePath;
	private Vector2 size;
	
	public Coin(Vector2 position, String imagePath, int value) {
		super(position,RoomInfos.ITEM_SIZE,imagePath, value);
		this.position = position;
		this.size = RoomInfos.ITEM_SIZE;
		this.imagePath = imagePath;
		this.value = value;
	}

	//Getters & Setters
	
	public Vector2 getPosition() {
		return position;
	}

	public void setPosition(Vector2 position) {
		this.position = position;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public Vector2 getSize() {
		return size;
	}

	public void setSize(Vector2 size) {
		this.size = size;
	}
	
	
	
}
