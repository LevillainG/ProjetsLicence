package gameWorld;

import libraries.StdDraw;
import libraries.Vector2;
import resources.ImagePaths;
import resources.ObstaclesInfos;
import resources.RoomInfos;

public class Door{

	Vector2 position;
	Vector2 size;
	String imagePath;
	boolean opened;
	Room nextRoom;
	Room previousRoom;

	public Door(Vector2 position) {
		this.position = position;
		this.size = RoomInfos.TILE_SIZE;
		this.imagePath = ImagePaths.CLOSED_DOOR;
		this.opened = false;
	}

	public void drawGameObject()
	{
		if(opened&&nextRoom!=null || opened&&previousRoom != null) {
			if(opened&&nextRoom!=null && nextRoom.getRoomType().equals("Boss")) {
				StdDraw.picture(getPosition().getX(), getPosition().getY(), ImagePaths.BOSS_DOOR_OPEN, getSize().getX(), getSize().getY(),
						0);
			}
			else {
				StdDraw.picture(getPosition().getX(), getPosition().getY(), ImagePaths.OPENED_DOOR, getSize().getX(), getSize().getY(),
						0);
			}
		}
		else {
			StdDraw.picture(getPosition().getX(), getPosition().getY(), getImagePath(), getSize().getX(), getSize().getY(),
					0);
		}

	}

	//Getters & Setters
	public Vector2 getPosition() {
		return position;
	}

	public void setPosition(Vector2 position) {
		this.position = position;
	}

	public Vector2 getSize() {
		return size;
	}

	public void setSize(Vector2 size) {
		this.size = size;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public boolean isOpened() {
		return opened;
	}

	public void setOpened(boolean opened) {
		this.opened = opened;
	}

	public Room getNextRoom() {
		return nextRoom;
	}

	public void setNextRoom(Room nextRoom) {
		this.nextRoom = nextRoom;
	}

	public Room getPreviousRoom() {
		return previousRoom;
	}

	public void setPreviousRoom(Room previousRoom) {
		this.previousRoom = previousRoom;
	}



}
