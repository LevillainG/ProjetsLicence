package gameWorld;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import gameobjects.BasicEnemy;
import gameobjects.BloodOfTheMartyr;
import gameobjects.Coin;
import gameobjects.HalfHeart;
import gameobjects.Heart;
import gameobjects.Hero;
import gameobjects.HpUp;
import gameobjects.Item;
import gameobjects.Tear;
import libraries.StdDraw;
import libraries.Vector2;
import resources.Controls;
import resources.HeroInfos;
import resources.ImagePaths;
import resources.RoomInfos;

public class GameWorld
{
	private Room lastRoom;
	private Room currentRoom;
	private Hero hero;

	// A world needs a hero
	public GameWorld(Hero hero, Dungeon dungeon)
	{
		this.hero = hero;
		currentRoom = dungeon.getDungeon().get(0);
		lastRoom = currentRoom;
		hero.setCurrentRoom(currentRoom);
	}

	public void processUserInput()
	{
		processKeysForMovement();
		processKeysForTears();
		processKeysForCheats();
	}

	public boolean gameOver()
	{
		if(hero.getHealth() <= 0) {
			StdDraw.picture(0.5, 0.5, ImagePaths.LOSE_SCREEN);
			StdDraw.show();
			return true;
		}
		if(currentRoom.getRoomType().equals("Boss")) {
			if(!currentRoom.getBoss().isAlive()) {
				StdDraw.picture(0.5, 0.5, ImagePaths.WIN_SCREEN);
				StdDraw.show();
				return true;
			}
		}
		return false;
	}

	public void updateGameObjects()
	{
		currentRoom.updateRoom();
		System.out.println(currentRoom.getExits());
	}

	public void drawGameObjects()
	{
		currentRoom.drawRoom();
	}

	/*
	 * Check all events linked to collisions
	 */
	public void collisions () {
		checkDoorCollision();
		tearCollision();
		trapCollision();
		monsterLife();
		itemCollision();
	}


	/*
	 * Manage the life of monsters
	 */
	private void monsterLife() {
		Map <Vector2, BasicEnemy> monsters = currentRoom.getEnemies();
		if(currentRoom.getRoomType().equals("Mob")) {
			Iterator<Entry<Vector2,BasicEnemy>> iterator = monsters.entrySet().iterator();
			while(iterator.hasNext()) {
				Entry<Vector2,BasicEnemy> monster = iterator.next();
				if(hero.getTears().getPosition().distance(monster.getValue().getPosition()) < RoomInfos.HALF_TILE_SIZE.euclidianNorm()
						&& hero.getTears().isShot()) {
					hero.getTears().setCollide(true);

					//Cheat godMode
					if(hero.isGodMode()) {
						monster.getValue().setHealth(0);
					}
					else {
						monster.getValue().setHealth(monster.getValue().getHealth()-hero.getDamage());
					}
					if(monster.getValue().getHealth() <= 0) {
						iterator.remove();
					}
				}
			}
		}
	}


	/*
	 * Manage the item collect
	 */
	private void itemCollision() {
		Map<Vector2,Item> items = currentRoom.getItems();
		if((currentRoom.getRoomType().equals("Mob") || currentRoom.getRoomType().equals("Merchant")) && currentRoom.isRoomCleared()) {
			for(Item item : items.values()) {
				if(item.getPosition().distance(hero.getPosition()) < RoomInfos.HALF_TILE_SIZE.euclidianNorm()) {
					//Different cases
					if(item instanceof Coin) {
						if(hero.getMaxMoney()>hero.getMoney()) {
							hero.setMoney(item.getValue()+hero.getMoney());
							//If the limit is crossed
							if(hero.getMoney()>hero.getMaxMoney()) {
								hero.setMoney(hero.getMaxMoney());
							}
							item.setCollected(true);
						}
					}
					else if(item instanceof Heart || item instanceof HalfHeart) {
						if(hero.getHealth()<hero.getMaxHealth()) {
							if(checkPickup(item)) {
								if(hero.getHealth()+item.getValue() > hero.getMaxHealth()) {
									hero.setHealth(hero.getMaxHealth());
								}
								else {
									hero.setHealth(hero.getHealth()+item.getValue());
								}

								item.setCollected(true);
							}
						}
					}
					else if(item instanceof HpUp) {
						if(checkPickup(item)) {
							hero.setMaxHealth(hero.getMaxHealth()+2);
							hero.setHealth(hero.getMaxHealth());
							item.setCollected(true);
						}
					}
					else if(item instanceof BloodOfTheMartyr) {
						if(checkPickup(item)) {
							hero.setDamage(hero.getDamage()+1);
							item.setCollected(true);
						}
					}
				}
			}
		}
	}

	/*
	 * Check if the item can be picked
	 */
	private boolean checkPickup(Item item) {
		//If the item is in the "Merchant" room :
		if(item.isPriced()) {
			if(item.getPrice() < hero.getMoney()) {
				hero.setMoney(hero.getMoney()-item.getPrice());
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return true;
		}
	}

	/*
	 * Check if the player collides with a trap
	 */
	private void trapCollision() {
		Map<Vector2, Trap> traps = currentRoom.getTraps();
		if(currentRoom.getRoomType().equals("Mob") || currentRoom.getRoomType().equals("Normal")) {
			for(Trap trap : traps.values()) {
				if(trap instanceof Spikes) {
					if(trap.getPosition().distance(hero.getPosition()) < RoomInfos.HALF_TILE_SIZE.euclidianNorm()) {
						hero.setHealth(hero.getHealth()-1);
					}
				}
			}
		}
	}

	/*
	 * Check if the tear collide and must end
	 */
	private void tearCollision() {
		Tear tear = hero.getTears();
		if(tear.isCollide()) {
			tear = null;
			hero.setTears(new Tear(hero.getPosition()));
		}
		List <Vector2> forbiddenTiles = currentRoom.getForbiddenTiles();
		for(Vector2 position : forbiddenTiles) {
			if(tear != null) {
				if(tear.getPosition().distance(position) < HeroInfos.TEAR_SIZE.getX() | tear.getPosition().distance(position) < HeroInfos.ISAAC_SIZE.getY()) {
					tear.setCollide(true);

				}
			}
		}
	}

	/*
	 * check if the player collides with a door
	 */
	private void checkDoorCollision() {
		List<Door> exits = currentRoom.getExits();
		Door entry = currentRoom.getEntry();

		if(currentRoom.getRoomType() != "Spawn") {
			if(hero.getPosition().distance(entry.getPosition()) < HeroInfos.ISAAC_SIZE.getX()*1.35 | hero.getPosition().distance(entry.getPosition()) < HeroInfos.ISAAC_SIZE.getY()*1.35 && entry.isOpened()) {
				this.lastRoom = currentRoom;
				this.currentRoom = entry.getPreviousRoom();
				hero.setCurrentRoom(currentRoom);
				setPlayerPositionRoomExit();
			}
		}

		for(Door door : exits) {
			if(hero.getPosition().distance(door.getPosition()) < HeroInfos.ISAAC_SIZE.getX()*1.35 | hero.getPosition().distance(door.getPosition()) < HeroInfos.ISAAC_SIZE.getY()*1.35 && door.isOpened()) {
				this.currentRoom = door.getNextRoom();
				hero.setCurrentRoom(currentRoom);
				setPlayerPositionRoomEntry();
			}

		}
	}

	/*
	 * Set the position of the player near the door
	 */
	private void setPlayerPositionRoomEntry () {
		if(currentRoom.getEntry().getPosition().equals(Room.posNorth)) {
			hero.setPosition(Room.playerNorth);
		}
		else if(currentRoom.getEntry().getPosition().equals(Room.posSouth)) {
			hero.setPosition(Room.playerSouth);
		}
		else if(currentRoom.getEntry().getPosition().equals(Room.posWest)) {
			hero.setPosition(Room.playerWest);
		}
		else if(currentRoom.getEntry().getPosition().equals(Room.posEast)) {
			hero.setPosition(Room.playerEast);
		}

	}

	private void setPlayerPositionRoomExit () {

		if(lastRoom.getEntry().getPosition().equals(Room.posNorth)) {
			hero.setPosition(Room.playerSouth);
		}
		else if(lastRoom.getEntry().getPosition().equals(Room.posSouth)) {
			hero.setPosition(Room.playerNorth);
		}
		else if(lastRoom.getEntry().getPosition().equals(Room.posWest)) {
			hero.setPosition(Room.playerEast);
		}
		else if(lastRoom.getEntry().getPosition().equals(Room.posEast)) {
			hero.setPosition(Room.playerWest);
		}

	}



	/**
	 * For each case, move the player
	 * @param code
	 * @param O
	 */



	private void processKeysForMovement()
	{
		if (StdDraw.isKeyPressed(Controls.goUp))
		{
			hero.goUpNext();
		}
		if (StdDraw.isKeyPressed(Controls.goDown))
		{
			hero.goDownNext();
		}
		if (StdDraw.isKeyPressed(Controls.goRight))
		{
			hero.goRightNext();
		}
		if (StdDraw.isKeyPressed(Controls.goLeft))
		{
			hero.goLeftNext();
		}
	}

	private void processKeysForTears() {
		if (StdDraw.isKeyPressed(Controls.shootUp))
		{
			hero.shootUpNext();
		}
		if (StdDraw.isKeyPressed(Controls.shootDown))
		{
			hero.shootDownNext();
		}
		if (StdDraw.isKeyPressed(Controls.shootRight))
		{
			hero.shootRightNext();
		}
		if (StdDraw.isKeyPressed(Controls.shootLeft))
		{
			hero.shootLeftNext();
		}
	}

	private void processKeysForCheats() {
		if(StdDraw.isKeyPressed(Controls.invincible))
		{
			if(hero.isInvicible()) {
				hero.setInvicible(false);
				hero.setInvincibleCounter(0);
			}
			else {
				hero.setInvicible(true);
				hero.setInvincibleCounter(999999999);
			}
		}
		if(StdDraw.isKeyPressed(Controls.fast)) 
		{
			hero.setSpeed(0.02);
		}
		if(StdDraw.isKeyPressed(Controls.kill)) 
		{
			if(currentRoom.getRoomType().equals("Mob")) {
				currentRoom.setEnemies(new HashMap<Vector2,BasicEnemy>());
			}
			if(currentRoom.getRoomType().equals("Boss")) {
				currentRoom.getBoss().setAlive(false);
			}
		}
		if(StdDraw.isKeyPressed(Controls.instantKill)) 
		{
			if(hero.isGodMode()) {
				hero.setGodMode(false);
			}
			else {
				hero.setGodMode(true);
			}
		}
		if(StdDraw.isKeyPressed(Controls.money)) {
			hero.setMoney(hero.getMoney()+10);
			if(hero.getMoney()>hero.getMaxMoney()) {
				hero.setMoney(hero.getMaxMoney());
			}
		}
	}
}
