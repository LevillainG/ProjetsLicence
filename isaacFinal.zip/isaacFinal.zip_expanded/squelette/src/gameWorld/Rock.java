package gameWorld;

import libraries.Vector2;
import resources.ImagePaths;
import resources.ObstaclesInfos;

public class Rock extends Obstacles{

	public Rock(Vector2 position) {
		super(position, ObstaclesInfos.ROCK_SIZE,ImagePaths.ROCK);
	}

}
