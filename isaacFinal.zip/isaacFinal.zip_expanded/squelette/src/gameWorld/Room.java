package gameWorld;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import gameobjects.BasicEnemy;
import gameobjects.BloodOfTheMartyr;
import gameobjects.Boss;
import gameobjects.Coin;
import gameobjects.Dime;
import gameobjects.Fly;
import gameobjects.HalfHeart;
import gameobjects.Heart;
import gameobjects.Hero;
import gameobjects.HpUp;
import gameobjects.Item;
import gameobjects.Nickel;
import gameobjects.Penny;
import gameobjects.Spider;
import gameobjects.Tear;
import libraries.MyMaths;
import libraries.Physics;
import libraries.StdDraw;
import libraries.Vector2;
import resources.RoomInfos;

public class Room
{
	//Extremities of the room
	public static final Vector2 posWest = positionFromTileIndex(0, RoomInfos.NB_TILES/2);
	public static final Vector2 posEast = positionFromTileIndex(RoomInfos.NB_TILES-1, RoomInfos.NB_TILES/2);
	public static final Vector2 posNorth = positionFromTileIndex(RoomInfos.NB_TILES/2, RoomInfos.NB_TILES-1);
	public static final Vector2 posSouth = positionFromTileIndex(RoomInfos.NB_TILES/2, 0);

	//Position where the player appear when he enters a room
	public static final Vector2 playerWest = positionFromTileIndex(RoomInfos.NB_TILES-(RoomInfos.NB_TILES-1), RoomInfos.NB_TILES/2);
	public static final Vector2 playerEast = positionFromTileIndex(RoomInfos.NB_TILES-2, RoomInfos.NB_TILES/2);
	public static final Vector2 playerNorth = positionFromTileIndex(RoomInfos.NB_TILES/2, RoomInfos.NB_TILES-2);
	public static final Vector2 playerSouth = positionFromTileIndex(RoomInfos.NB_TILES/2, RoomInfos.NB_TILES-(RoomInfos.NB_TILES-1));

	private Hero hero;

	//Tiles for generation & enemies
	private Map<Vector2, BasicEnemy> enemies;
	private Boss boss;
	private Map<Vector2, Obstacles> obstacles;
	private Map<Vector2, Trap> traps;
	private Map<Vector2,Door> doors;
	private Map<Vector2,Wall> walls;
	private List<Vector2> forbiddenTiles;
	private Map<Vector2,Item> items;

	//Doors that contain infos for the next rooms
	private Door entry;
	private List<Door> exits;
	private boolean roomCleared;

	private String roomType; // "Spawn" -> Spawn, "Mob" -> Room with monsters, "Merchant" -> Room with merchant, "Normal" -> Room without monsters, "Boss" -> Boss room



	public Room(Hero hero, String roomType)
	{
		this.hero = hero;
		this.roomType =  roomType;
		this.roomCleared = false;
		generateRoom();
		hero.setCurrentRoom(this);
	}


	/*
	 * Generation
	 */

	void generateRoom() {
		if(roomType.equals("Spawn")) {
			createForbiddenList();
			generateWalls();
			generateDoors();
			this.roomCleared = true;
		}
		if(roomType.equals("Mob")) {
			createForbiddenList();
			generateWalls();
			generateDoors();
			generateObstacles();
			generateTraps();
			generateEnemies();
			generateItems();
		}
		if(roomType.equals("Normal")) {
			createForbiddenList();
			generateWalls();
			generateDoors();
			generateObstacles();
			generateTraps();

		}
		if(roomType.equals("Boss")) {
			createForbiddenList();
			generateWalls();
			generateDoors();
			generateObstacles();
			generateBoss();
		}
		if(roomType.equals("Merchant")) {
			createForbiddenList();
			generateWalls();
			generateDoors();
			generateMerchant();
			this.roomCleared = true;
		}
	}


	//Generate the doors needed for the room
	private void generateDoors() {
		if(this.roomType.equals("Spawn")) {
			doors = new HashMap<Vector2,Door>(1);
			doors.put(posSouth, new Door(posSouth));
			doors.get(posSouth).setOpened(true);
			addForbiddenTile(posSouth);
		}
		else {
			doors = new HashMap<Vector2,Door>(4);
			doors.put(posWest, new Door(posWest));
			doors.put(posEast, new Door(posEast));
			doors.put(posNorth, new Door(posNorth));
			doors.put(posSouth, new Door(posSouth));

			addForbiddenTile(posWest);
			addForbiddenTile(posEast);
			addForbiddenTile(posNorth);
			addForbiddenTile(posSouth);
		}
	}

	//Generate the walls of the room
	private void generateWalls() {
		walls = new HashMap<Vector2,Wall>(RoomInfos.NB_TILES * 4);
		for(int i = 0; i<RoomInfos.NB_TILES;i++) {
			Vector2 position = positionFromTileIndex(0, i);

			if(isOnDoor(position)) {
				continue;
			}

			walls.put(position, new Wall(position));
			addForbiddenTile(position);
		}
		for(int i = 0; i<RoomInfos.NB_TILES;i++) {
			Vector2 position = positionFromTileIndex(i, 0);

			if(isOnDoor(position)) {
				continue;
			}

			walls.put(position, new Wall(position));
			addForbiddenTile(position);
		}
		for(int i = 0; i<RoomInfos.NB_TILES;i++) {
			Vector2 position = positionFromTileIndex(RoomInfos.NB_TILES-1, i);

			if(isOnDoor(position)) {
				continue;
			}

			walls.put(position, new Wall(position));
			addForbiddenTile(position);
		}
		for(int i = 0; i<RoomInfos.NB_TILES;i++) {
			Vector2 position = positionFromTileIndex(i, RoomInfos.NB_TILES-1);

			if(isOnDoor(position)) {
				continue;
			}

			walls.put(position, new Wall(position));
			addForbiddenTile(position);
		}
	}

	//little method for walls that check if the wall is placed where the doors should be
	private boolean isOnDoor (Vector2 position) {
		if(roomType.equals("Spawn")) {
			return position.equals(posSouth);
		}
		return position.equals(posNorth) || position.equals(posWest) || position.equals(posEast) || position.equals(posSouth); 
	}

	//Generate a random number of enemies between 2 limits
	private void generateEnemies () {
		Random ran = new Random();
		int monsterCount = ran.nextInt(RoomInfos.MAX_MOB - RoomInfos.MIN_MOB) + RoomInfos.MIN_MOB;
		enemies = new HashMap<Vector2,BasicEnemy>(monsterCount);
		for(int i = 0; i<monsterCount/2;i++) {
			Vector2 position = randomPosition();
			enemies.put(position,new Spider(position, hero, this));
		}
		for(int i = 0; i<monsterCount/2;i++)
		{
			Vector2 position = randomPosition();
			enemies.put(position,new Fly(position, hero, this));
		}
	}

	//Generate the boss
	private void generateBoss() {
		this.boss = new Boss(RoomInfos.POSITION_CENTER_OF_ROOM, this, hero);
	}


	private void generateObstacles () {

		//Special case for the boss room
		if(this.roomType.equals("Boss")) {
			obstacles = new HashMap<Vector2, Obstacles>(4);
			obstacles.put(RoomInfos.BOSS_ROCK_NORTH, new Rock(RoomInfos.BOSS_ROCK_NORTH));
			obstacles.put(RoomInfos.BOSS_ROCK_SOUTH, new Rock(RoomInfos.BOSS_ROCK_SOUTH));
			obstacles.put(RoomInfos.BOSS_ROCK_EAST, new Rock(RoomInfos.BOSS_ROCK_EAST));
			obstacles.put(RoomInfos.BOSS_ROCK_WEST, new Rock(RoomInfos.BOSS_ROCK_WEST));
			addForbiddenTile(RoomInfos.BOSS_ROCK_NORTH);
			addForbiddenTile(RoomInfos.BOSS_ROCK_SOUTH);
			addForbiddenTile(RoomInfos.BOSS_ROCK_EAST);
			addForbiddenTile(RoomInfos.BOSS_ROCK_WEST);
		}
		else {
			Random ran = new Random();
			int obstaclesCount = ran.nextInt(RoomInfos.MAX_OBSTACLES - RoomInfos.MIN_OBSTACLES) + RoomInfos.MIN_OBSTACLES;
			obstacles = new HashMap<Vector2,Obstacles>(obstaclesCount);
			for(int i = 0; i<obstaclesCount;i++) {
				Vector2 position = randomPosition();

				if(isOnDoor(position)) {
					continue;
				}

				obstacles.put(position,new Rock(position));
				addForbiddenTile(position);
			}
		}
	}

	private void generateTraps () {
		Random ran = new Random();
		int trapsCount = ran.nextInt(RoomInfos.MAX_TRAPS - RoomInfos.MIN_TRAPS) + RoomInfos.MIN_TRAPS;
		traps = new HashMap<Vector2,Trap>(trapsCount);
		for(int i = 0; i<trapsCount; i++) {
			Vector2 position = randomPosition();

			if(isOnDoor(position)) {
				continue;
			}

			traps.put(position, new Spikes(position));
		}
	}

	//Generate items when the room is cleared
	private void generateItems() {
		items = new HashMap<Vector2,Item>();
		Random ran = new Random();
		int randomNum = ran.nextInt(13);
		if(randomNum<=2) {
			Vector2 position = randomPosition();
			HalfHeart halfheart = new HalfHeart(position);
			items.put(position, halfheart);
		}
		else if(randomNum<=4) {
			Vector2 position = randomPosition();
			Heart heart = new Heart(position);
			items.put(position, heart);
		}
		else if(randomNum<=5) {
			Vector2 position = randomPosition();
			Penny penny = new Penny(position);
			items.put(position, penny);
		}
		else if(randomNum<=8) {
			Vector2 position = randomPosition();
			Nickel nickel = new Nickel(position);
			items.put(position, nickel);
		}
		else if(randomNum<=10) {
			Vector2 position = randomPosition();
			Dime dime = new Dime(position);
			items.put(position, dime);
		}
		else if(randomNum==11) {
			Vector2 position = randomPosition();
			HpUp hpup = new HpUp(position);
			items.put(position, hpup);
		}
		else if(randomNum==12) {
			Vector2 position = randomPosition();
			BloodOfTheMartyr botm = new BloodOfTheMartyr(position);
			items.put(position, botm);
		}
	}

	//Generate the merchant
	private void generateMerchant() {
		Random ran = new Random();
		items = new HashMap<Vector2,Item>(3);

		for(int i = 0; i<2; i++) {
			int random = ran.nextInt(10);
			Vector2 position = new Vector2(RoomInfos.POSITION_CENTER_OF_ROOM);
			if(i ==0) {
				position.addX(-0.1);
			}							//Place the object
			else {
				position.addX(0.1);
			}
			//Create first item
			if(random <= 3) {
				Heart heart = new Heart(position);
				heart.setPriced(true);
				heart.setPrice(5);
				items.put(position, heart);
			}
			else if(random <=9) {
				HalfHeart halfheart = new HalfHeart(position);
				halfheart.setPriced(true);
				halfheart.setPrice(2);
				items.put(position, halfheart);
			}
		}
		int randomNum = ran.nextInt(2);
		if(randomNum==0) {
			Vector2 position = new Vector2(RoomInfos.POSITION_CENTER_OF_ROOM);
			BloodOfTheMartyr botm = new BloodOfTheMartyr(position);
			botm.setPriced(true);
			botm.setPrice(15);
			items.put(position, botm);
		}
		else {
			Vector2 position = new Vector2(RoomInfos.POSITION_CENTER_OF_ROOM);
			HpUp hpup = new HpUp(position);
			hpup.setPriced(true);
			hpup.setPrice(15);
			items.put(position, hpup);
		}
	}

	//Generate a randomPosition
	private Vector2 randomPosition() {
		Vector2 position;
		do {
			Random ran = new Random();
			int x = ran.nextInt(RoomInfos.NB_TILES-1);
			int y = ran.nextInt(RoomInfos.NB_TILES-1);
			position = positionFromTileIndex(x, y);
		} while (!positionCheck(position));
		return position;
	}


	//Check if the position is already taken
	private boolean positionCheck(Vector2 position) {
		boolean positionFree = true;
		createForbiddenList();
		for(int i = 0;i<forbiddenTiles.size();i++) {
			if(position.equals(forbiddenTiles.get(i))) {
				positionFree = false;
			}
		}
		if(position.equals(playerEast) | position.equals(playerWest) | position.equals(playerNorth) | position.equals(playerSouth)) {
			positionFree = false;
		}
		if(traps != null) {
			for(Trap trap : traps.values()) {
				if(position.equals(trap.getPosition())) {
					positionFree = false;
				}
			}
		}
		return positionFree;
	}

	/*
	 * create list of forbiddenTiles
	 */
	private void createForbiddenList() {
		Set posObstacles;
		Set posWalls;
		Set posDoors;
		Set posTraps;
		boolean positionFree = true;
		int size = 0;


		//Gets values of Maps

		if(obstacles != null && !obstacles.isEmpty()) {
			posObstacles = obstacles.keySet();
			size += posObstacles.size();
		}
		else {
			posObstacles = new HashSet<Vector2>();
		}
		if(walls != null && !walls.isEmpty()) {
			posWalls = walls.keySet();
			size += posWalls.size();
		}
		else {
			posWalls = new HashSet<Vector2>();
		}
		if(doors != null && !doors.isEmpty()) {
			posDoors = doors.keySet();
			size += posDoors.size();
		}
		else {
			posDoors = new HashSet<Vector2>();
		}


		List <Vector2> forbiddenTiles = new ArrayList<Vector2>(size);
		forbiddenTiles.addAll(posObstacles);
		forbiddenTiles.addAll(posWalls);
		forbiddenTiles.addAll(posDoors);

		setForbiddenTiles(forbiddenTiles);

	}

	/*
	 * add elements to the forbidden list
	 */
	private void addForbiddenTile(Vector2 position) {
		forbiddenTiles.add(position);
	}


	/*
	 * Check if the doors can be opened
	 */
	private void roomCleared() {
		if(roomType.equals("Mob")) {
			if(enemies.isEmpty()) {
				roomCleared = true;
				for(Door door : doors.values()) {
					door.setOpened(true);
				}
			}
		}
		if(roomType.equals("Normal") || roomType.equals("Merchant")) {
			roomCleared = true;
			for(Door door : doors.values()) {
				door.setOpened(true);
			}
		}
	}


	/*
	 * Make every entity that compose a room process one step
	 */
	public void updateRoom()
	{
		makeHeroPlay();
		makeEnemiesPlay();
		makeBossPlay();
		roomCleared();
		checkItemCollect();
	}


	private void makeHeroPlay()
	{
		hero.updateGameObject();
	}

	private void makeEnemiesPlay() {
		if(this.roomType.equals("Mob")) {
			for(BasicEnemy enemy : enemies.values()) {
				enemy.updateGameObject();
			}
		}
	}

	private void checkItemCollect() {
		if(roomType.equals("Mob") || roomType.equals("Merchant")) {
			items.entrySet().removeIf(e -> e.getValue().isCollected()==true);
		}
	}

	private void makeBossPlay() {
		if(this.roomType.equals("Boss")) {
			boss.updateGameObject();
		}
	}
	/*
	 * Drawing
	 */
	public void drawRoom() 
	{
		//Set background color.
		StdDraw.setPenColor(StdDraw.GRAY);
		for (int i = 0; i < RoomInfos.NB_TILES; i++)
		{
			for (int j = 0; j < RoomInfos.NB_TILES; j++)
			{
				Vector2 position = positionFromTileIndex(i, j);
				StdDraw.filledRectangle(position.getX(), position.getY(), RoomInfos.HALF_TILE_SIZE.getX(),
						RoomInfos.HALF_TILE_SIZE.getY());
			}
		}
		if(hero.getTears().isShot()) {
			hero.getTears().drawGameObject();
		}
		if(roomType.equals("Spawn")) {
			drawWalls();
			drawDoors();
		}
		if(roomType.equals("Normal")) {
			drawWalls();
			drawDoors();
			drawObstacles();
			drawTraps();
		}
		if(roomType.equals("Mob")) {
			drawWalls();
			drawDoors();
			drawObstacles();
			drawTraps();
			drawEnemies();
			drawItems();
		}
		if(roomType.equals("Merchant")) {
			drawWalls();
			drawDoors();
			drawItems();
		}
		if(roomType.equals("Boss")) {
			drawWalls();
			drawDoors();
			drawObstacles();
			drawBoss();
		}
		hero.drawGameObject();
	}
	//Draw Walls
	private void drawWalls() {
		for(Wall wall : walls.values()) {
			wall.drawGameObject();
		}
	}
	//Draw doors
	private void drawDoors() {
		for(Door door: doors.values()) {
			door.drawGameObject();
		}
	}
	//Draw Obstacles
	private void drawObstacles() {
		for(Obstacles obstacle : obstacles.values()) {
			obstacle.drawGameObject();
		}
	}
	//Draw Traps
	private void drawTraps() {
		for(Trap trap : traps.values()) {
			trap.drawGameObject();
		}
	}
	//Draw Items when room is cleared
	private void drawItems() {
		if(this.isRoomCleared()) {
			for(Item item : items.values()) {
				item.drawGameObject();
			}
		}
	}
	//Draw Enemies
	private void drawEnemies() {
		for(BasicEnemy enemy : enemies.values()) {
			enemy.drawGameObject();

			if(enemy.getBall() != null) {
				enemy.getBall().drawGameObject();
			}
		}
	}
	//Draw Boss
	private void drawBoss() {
		boss.drawGameObject();
		if(boss.getBall().isShot()) {
			boss.getBall().drawGameObject();
		}
	}
	/**
	 * Convert a tile index to a 0-1 position.
	 * 
	 * @param indexX
	 * @param indexY
	 * @return
	 */
	public static Vector2 positionFromTileIndex(int indexX, int indexY)
	{
		return new Vector2(indexX * RoomInfos.TILE_WIDTH + RoomInfos.HALF_TILE_SIZE.getX(),
				indexY * RoomInfos.TILE_HEIGHT + RoomInfos.HALF_TILE_SIZE.getY());
	}


	//Getters & Setters
	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}



	public List<Vector2> getForbiddenTiles() {
		return forbiddenTiles;
	}


	public void setForbiddenTiles(List<Vector2> forbiddenTiles) {
		this.forbiddenTiles = forbiddenTiles;
	}


	public Map<Vector2, BasicEnemy> getEnemies() {
		return enemies;
	}


	public void setEnemies(Map<Vector2, BasicEnemy> enemies) {
		this.enemies = enemies;
	}


	public Map<Vector2, Obstacles> getObstacles() {
		return obstacles;
	}


	public void setObstacles(Map<Vector2, Obstacles> obstacles) {
		this.obstacles = obstacles;
	}


	public Map<Vector2, Door> getDoors() {
		return doors;
	}


	public void setDoors(Map<Vector2, Door> doors) {
		this.doors = doors;
	}


	public Map<Vector2, Wall> getWalls() {
		return walls;
	}


	public void setWalls(Map<Vector2, Wall> walls) {
		this.walls = walls;
	}


	public List<Door> getExits() {
		return exits;
	}


	public void setExits(List<Door> nextRooms) {
		this.exits = nextRooms;
	}


	public Door getEntry() {
		return entry;
	}


	public void setEntry(Door entry) {
		this.entry = entry;
	}


	public Hero getHero() {
		return hero;
	}


	public void setHero(Hero hero) {
		this.hero = hero;
	}


	public boolean isRoomCleared() {
		return roomCleared;
	}


	public void setRoomCleared(boolean roomCleared) {
		this.roomCleared = roomCleared;
	}


	public Map<Vector2, Trap> getTraps() {
		return traps;
	}


	public void setTraps(Map<Vector2, Trap> traps) {
		this.traps = traps;
	}


	public Boss getBoss() {
		return boss;
	}


	public void setBoss(Boss boss) {
		this.boss = boss;
	}


	public Map<Vector2, Item> getItems() {
		return items;
	}


	public void setItems(Map<Vector2, Item> items) {
		this.items = items;
	}



}
