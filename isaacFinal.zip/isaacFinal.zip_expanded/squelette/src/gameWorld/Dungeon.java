package gameWorld;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import gameobjects.Hero;
import libraries.Tools;
import libraries.Vector2;
import resources.RoomInfos;
import resources.RoomInfos.DoorDirections;

public class Dungeon {

	private int min_room;
	private int max_room;
	private List<Room> dungeon;
	private int totalRooms;
	private Hero hero;

	private int roomLeft; //Used to create the road


	public Dungeon(int min_room, int max_room, Hero hero) {
		this.min_room = min_room;
		this.max_room = max_room;
		this.hero = hero;
		if(min_room < 1) {this.min_room = 1;}
		if(max_room == min_room || max_room < 1) {this.max_room += this.min_room;}
		Random ran = new Random();
		this.totalRooms = ran.nextInt(this.max_room - this.min_room) + this.min_room;
		this.dungeon = new ArrayList<Room>(totalRooms+3);
		generateRooms();
	}

	private void generateRooms () {
		dungeon.add(new Room(hero, "Spawn"));
		dungeon.add(new Room(hero,"Merchant"));
		for(int i = 0; i<totalRooms;i++) {
			Random ran = new Random();
			if(ran.nextInt(2) == 0) {
				dungeon.add(new Room(hero, "Mob"));
			}
			else {
				dungeon.add(new Room(hero, "Normal"));
			}
		}
		dungeon.add(new Room(hero,"Boss"));
		this.roomLeft = dungeon.size()-1;
		createRoad();
	}


	private void createRoad () {
		int counter = 1; //Start at 1 because we do not count the spawn
		int index = 0;
		Vector2 previousDoor = Room.posSouth;
		for(Room room : dungeon) {
			//Counting the number of rooms left
			//Initializing the Lists & Maps
			Map <Vector2, Door> doors = room.getDoors();
			List <Door> exits = new ArrayList <Door>();

			//For the spawn
			if(room.getRoomType().equals("Spawn")) {
				exits.add(doors.get(Room.posSouth));
				room.setExits(exits);
				exits.get(0).setNextRoom(dungeon.get(1));
				roomLeft -= 1;
			}
			else{
				if(room.getEntry() == null) {
					createEntry(room, previousDoor, doors, dungeon.get(index-1));
				}
				previousDoor = room.getEntry().getPosition();
				room.setExits(chooseExits(previousDoor,4,counter,room,doors,exits));
				counter=dungeon.size()-roomLeft-1;
			}
			index++;
		}
	}

	private List<Door> chooseExits (Vector2 previousDoor,int bound,int counter,Room room, Map<Vector2, Door> doors, List<Door> exits) {

		if(roomLeft < 1) {
			return exits;
		}	
		Random ran = new Random();
		int nbrDoors;
		
		if(roomLeft == 1) {
			nbrDoors = 1;
		}
		else if(roomLeft <= 3) {
			nbrDoors = ran.nextInt(roomLeft-1)+1;
		}
		else {
			nbrDoors = ran.nextInt(bound - 1) + 1;
		}


		List<Vector2> choices = createChoices(previousDoor);

		if(room.getRoomType().equals("Boss")) {
			return exits;
		}

		

		else {
			roomLeft -= nbrDoors;
			for(int i = 1; i<=nbrDoors; i++) {
				if(i == 1) {
					exits.add(doors.get(choices.get(0)));
					doors.get(choices.get(0)).setNextRoom(dungeon.get(counter+i));	//Set next room on the door
					createEntry(dungeon.get(counter+i), choices.get(0), dungeon.get(counter+i).getDoors(), room);
				}
				if(i == 2) {
					exits.add(doors.get(choices.get(1)));
					doors.get(choices.get(1)).setNextRoom(dungeon.get(counter+i));
					createEntry(dungeon.get(counter+i), choices.get(1), dungeon.get(counter+i).getDoors(), room);
				}
				if(i == 3) {
					exits.add(doors.get(choices.get(2)));
					doors.get(choices.get(2)).setNextRoom(dungeon.get(counter+i));
					createEntry(dungeon.get(counter+i), choices.get(2), dungeon.get(counter+i).getDoors(), room);
				}
			}
		}
		return exits;
	}

	/*
	 * Method to create a list of enum depending of the entry door
	 */
	private List<Vector2> createChoices (Vector2 previousDoor) {
		List<Vector2> choices = new ArrayList<Vector2>(3);

		if(previousDoor.equals(Room.posNorth)) {
			choices.add(Tools.getEnumValue(DoorDirections.SOUTH));choices.add(Tools.getEnumValue(DoorDirections.EAST));choices.add(Tools.getEnumValue(DoorDirections.WEST));
		}
		if(previousDoor.equals(Room.posSouth)) {
			choices.add(Tools.getEnumValue(DoorDirections.NORTH));choices.add(Tools.getEnumValue(DoorDirections.EAST));choices.add(Tools.getEnumValue(DoorDirections.WEST));
		}
		if(previousDoor.equals(Room.posWest)) {
			choices.add(Tools.getEnumValue(DoorDirections.NORTH));choices.add(Tools.getEnumValue(DoorDirections.EAST));choices.add(Tools.getEnumValue(DoorDirections.SOUTH));
		}
		if(previousDoor.equals(Room.posEast)) {
			choices.add(Tools.getEnumValue(DoorDirections.NORTH));choices.add(Tools.getEnumValue(DoorDirections.SOUTH));choices.add(Tools.getEnumValue(DoorDirections.WEST));
		}
		return choices;
	}

	/*
	 * Method to create the entry door of each room
	 */
	private void createEntry(Room room, Vector2 doorPos, Map<Vector2, Door> doors, Room previousRoom) {

			if(doorPos.equals(Room.posNorth)) {
				room.setEntry(doors.get(Room.posSouth));
				room.getEntry().setPreviousRoom(previousRoom);
			}
			else if(doorPos.equals(Room.posSouth)) {
				room.setEntry(doors.get(Room.posNorth));
				room.getEntry().setPreviousRoom(previousRoom);
			}
			else if(doorPos.equals(Room.posEast)) {
				room.setEntry(doors.get(Room.posWest));
				room.getEntry().setPreviousRoom(previousRoom);
			}
			else if(doorPos.equals(Room.posWest)) {
				room.setEntry(doors.get(Room.posEast));
				room.getEntry().setPreviousRoom(previousRoom);
			}
	}	



	//Getters & Setters
	public int getMin_room() {
		return min_room;
	}

	public void setMin_room(int min_room) {
		this.min_room = min_room;
	}

	public int getMax_room() {
		return max_room;
	}

	public void setMax_room(int max_room) {
		this.max_room = max_room;
	}

	public List<Room> getDungeon() {
		return dungeon;
	}

	public void setDungeon(List<Room> dungeon) {
		this.dungeon = dungeon;
	}

	public int getTotalRooms() {
		return totalRooms;
	}

	public void setTotalRooms(int totalRooms) {
		this.totalRooms = totalRooms;
	}

	public Hero getHero() {
		return hero;
	}

	public void setHero(Hero hero) {
		this.hero = hero;
	}





}
