package gameWorld;

import libraries.StdDraw;
import libraries.Vector2;
import resources.ImagePaths;
import resources.RoomInfos;

public class Wall extends Obstacles{
	
	public Wall (Vector2 position) {
		super(position, RoomInfos.TILE_SIZE, ImagePaths.WALL);
	}
}
