package gameWorld;

import libraries.Vector2;
import resources.ImagePaths;
import resources.ObstaclesInfos;

public class Spikes extends Trap{

	public Spikes(Vector2 position) {
		super(position, ObstaclesInfos.SPIKES_SIZE,ImagePaths.SPIKES);
	}

}
