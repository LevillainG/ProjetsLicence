package libraries;

import gameWorld.Room;
import resources.RoomInfos;

public class Tools {

	
	public static Vector2 getEnumValue (RoomInfos.DoorDirections direction) {
		switch (direction) {
		case NORTH :
			return Room.posNorth;
		case SOUTH :
			return  Room.posSouth;
		case EAST :
			return 	Room.posEast;
		case WEST :
			return  Room.posWest;
		}
		return null;
		
	}
}
