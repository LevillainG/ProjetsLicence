package libraries;

public class MyMaths {
	//Return a double to the decimal wanted
	public static double round(double value, int nbrDecimal) {
		int scale = (int) Math.pow(10, nbrDecimal);
		return (double) Math.round(value * scale) / scale;
	}
}
