LEVILLAIN Gauthier

Le jeu est un rogue-like reprenant pour la majeure partie The Binding Of Isaac.

Lorsque vous lancez le jeu, un nombre prédéfini de salle sera crée (changeable dans le main en modifiant le nombre de salles max et min du donjon).
La première salle est le spawn, il n'y a rien. La deuxième salle est la salle du marchand, vous pouvez y acheter des objets qui ont été générés lors de la création du donjon.
Enfin les autres salles sont aléatoirement disposées, à vous de trouver la salle du Boss (remarquable à une porte différente). Si vous battez le boss vous gagnez la partie.
Si vos points de vies arrivent à 0, vous perdez.

A part la salle du boss, vous pouvez tomber sur deux types de salles : "Mob" ou "Normal".
Une salle Mob générera 2 ou 4 monstres (changeable dans RoomInfos). Et lorsque vous tuerez les monstres, un objet apparaîtra dans la salle.
Attention, dans toutes les salles aléatoires sont posés des pièges pouvant vous infliger des dégâts.

Monstres :

Le Spider : Un monstre qui ne traverse pas les obstacles mais qui est un peu plus rapide que le Fly.
Le Fly : Un monstre lent qui peut passer à travers les obstacles et qui tire un projectile vous poursuivant.
Le Boss : Il alterne entre les deux actions des monstres cités précedemment. Attention il est plus rapide que vous. Lorsque vous le battez, vous gagnez le jeu.

Les larmes :
Vous possédez une larme, lorsque vous la tirez, vous ne pouvez plus en tirer de nouvelle tant que celle-ci n'aie toucher un mur, un obstacle ou un monstre.
De base elle fait 1 point de dégâts, mais vous pouvez l'augmenter de 1 avec l'objet "Blood of the martyr";

(Il était prévu d'avoir la possibilité de rajouter des larmes grâce à un objet mais par manque de temps je n'ai pas pu le faire. D'où ce système)

Cheats : 
'i' : Vous rend invincible (ré-appuyez dessus pour l'enlever)
'k' : Tue tous les monstres de la salle
'p' : Vos tirs tuent tous les monstres en un coup
'l' : Vous êtes plus rapide
'o' : Vous gagnez 10 d'argent (maximum 20).

Réalisation du donjon aléatoire :
Pour réaliser le donjon aléatoire, je n'ai malheureusement pas trouvé d'inspiration sur internet, mon code est donc peut-être un peu compliqué.

Chaque salle possède 4 portes (hormis celle du boss et du spawn). Chaque porte possède l'information d'une possible salle suivante (nextRoom) ou d'une salle précédente (previousRoom).
Lors de la génération, je génère tout d'abord les salles dont j'ai besoin, puis je crée la "route" via une fonction appelée createRoad().
Cette fonction fais une boucle sur ma liste de "Room" et crée des sorties (si possible) pour chacune des salles.
Et en fonction des sorties de ces salles, j'attribue à la porte opposée de celle de sortie (par exemple, la porte de sortie est au Sud, alors la porte d'entrée de la salle attribuée à cette porte est Nord) la salle actuelle.
La salle du boss étant la dernière salle de la liste, elle n'a forcemment pas de salle suivante.


Gestion des collisions :
Pour réaliser les collisions, je me suis inspiré du système de Pac-Man.

Dans chaque "Room" se trouve une ArrayList appelée forbiddenTiles. Elle contient toutes les positions que le joueur n'est pas autorisé à atteindre. 
Ensuite j'ai juste vérifié à chaque update du jeu si le joueur ne se déplace pas sur une de ces tiles.

Gestion de l'IA :
Les monstres suivent le joueur, la distance entre le mosntre et le joueur crée un vecteur pour le monstre qui se déplace dans cette direction.
Malheureusement ce n'est pas parfait et les spider se bloquent souvent dans les rochers.

Enfin, lorsque le joueur prend des dégâts, il devient invincible pendant un court moment (tout comme le boss pour éviter qu'il se finisse trop rapidement) 