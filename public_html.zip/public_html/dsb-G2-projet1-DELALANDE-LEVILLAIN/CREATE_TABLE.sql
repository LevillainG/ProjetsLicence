create table Soldat (DogTag int unsigned primary key not null, Nom varchar(50));
create table Vehicule (VehTag int unsigned primary key not null, Sièges int unsigned, Reservoir int unsigned);
create table Equipage (CrewTag int unsigned primary key not null, Effectif int unsigned);
create table Bataillon (BatTag int unsigned primary key not null, EffectifSoldat int unsigned, EffectifVehicule int unsigned, ComTag int unsigned not null);
create table Commandant (ComTag int unsigned primary key not null, Nom varchar(50));
create table Ennemis (CampTag int unsigned primary key not null, EffectifSoldat int unsigned, EffectifVehicule int unsigned, EffectifCommandant int unsigned);

alter table Bataillon add foreign key (ComTag) references Commandant(ComTag);

create table soldatEstMembreEquipage (DogTag int unsigned not null, CrewTag int unsigned not null);
alter table soldatEstMembreEquipage add foreign key (DogTag) references Soldat(DogTag);
alter table soldatEstMembreEquipage add foreign key (CrewTag) references Equipage(CrewTag);

create table assigner (CrewTag int unsigned not null, VehTag int unsigned not null);
alter table assigner add foreign key (CrewTag) references Equipage(CrewTag);
alter table assigner add foreign key (VehTag) references Vehicule(VehTag);

create table soldatAppartient (DogTag int unsigned not null, BatTag int unsigned not null);
alter table soldatAppartient add foreign key (DogTag) references Soldat(DogTag);
alter table soldatAppartient add foreign key (BatTag) references Bataillon(BatTag);

create table engager(BatTag int unsigned not null, CampTag int unsigned not null);
alter table engager add foreign key (BatTag) references Bataillon(BatTag);
alter table engager add foreign key (CampTag) references Ennemis(CampTag);
