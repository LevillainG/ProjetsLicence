-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Ven 26 Février 2021 à 12:27
-- Version du serveur :  5.5.31
-- Version de PHP :  5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `base_madelalande`
--

-- --------------------------------------------------------

--
-- Structure de la table `assigner`
--

CREATE TABLE IF NOT EXISTS `assigner` (
  `CrewTag` int(10) unsigned NOT NULL,
  `VehTag` int(10) unsigned NOT NULL,
  KEY `CrewTag` (`CrewTag`),
  KEY `VehTag` (`VehTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `assigner`
--

INSERT INTO `assigner` (`CrewTag`, `VehTag`) VALUES
(543, 645),
(785, 87),
(576, 8765);

-- --------------------------------------------------------

--
-- Structure de la table `Bataillon`
--

CREATE TABLE IF NOT EXISTS `Bataillon` (
  `BatTag` int(10) unsigned NOT NULL,
  `EffectifSoldat` int(10) unsigned DEFAULT NULL,
  `EffectifVehicule` int(10) unsigned DEFAULT NULL,
  `ComTag` int(10) unsigned NOT NULL,
  PRIMARY KEY (`BatTag`),
  KEY `ComTag` (`ComTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Bataillon`
--

INSERT INTO `Bataillon` (`BatTag`, `EffectifSoldat`, `EffectifVehicule`, `ComTag`) VALUES
(36, 1065, 186, 3946),
(54, 576, 56, 8496),
(78, 313, 86, 164),
(645, 986, 0, 748),
(784, 456, 285, 1354),
(1584, 765, 78, 368),
(7845, 876, 256, 784),
(8754, 486, 67, 7964),
(87645, 684, 0, 78),
(786453, 570, 168, 45);

-- --------------------------------------------------------

--
-- Structure de la table `Commandant`
--

CREATE TABLE IF NOT EXISTS `Commandant` (
  `ComTag` int(10) unsigned NOT NULL,
  `Nom` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ComTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Commandant`
--

INSERT INTO `Commandant` (`ComTag`, `Nom`) VALUES
(45, 'Jean Fourbe'),
(78, 'Arnold Guéguér'),
(164, 'Richard Le Pauvre'),
(368, 'Donis Chon'),
(748, 'Pierre Le Rock'),
(784, 'Alain Térieur'),
(1354, 'Hélène Demimore'),
(3946, 'Eric Sévisse'),
(7964, 'Max Ça Passe'),
(8496, 'Christophe Sibate');

-- --------------------------------------------------------

--
-- Structure de la table `engager`
--

CREATE TABLE IF NOT EXISTS `engager` (
  `BatTag` int(10) unsigned NOT NULL,
  `CampTag` int(10) unsigned NOT NULL,
  KEY `BatTag` (`BatTag`),
  KEY `CampTag` (`CampTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `engager`
--

INSERT INTO `engager` (`BatTag`, `CampTag`) VALUES
(786453, 98),
(78, 56),
(54, 31),
(784, 97),
(1584, 97);

-- --------------------------------------------------------

--
-- Structure de la table `Ennemis`
--

CREATE TABLE IF NOT EXISTS `Ennemis` (
  `CampTag` int(10) unsigned NOT NULL,
  `EffectifSoldat` int(10) unsigned DEFAULT NULL,
  `EffectifVehicule` int(10) unsigned DEFAULT NULL,
  `EffectifCommandant` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`CampTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Ennemis`
--

INSERT INTO `Ennemis` (`CampTag`, `EffectifSoldat`, `EffectifVehicule`, `EffectifCommandant`) VALUES
(21, 78645, 18681, 132),
(31, 368, 48, 1),
(45, 13886, 865, 12),
(54, 5468, 354, 5),
(56, 15, 0, 1),
(64, 546, 56, 1),
(68, 786453, 138646, 2622),
(78, 678, 153, 1),
(97, 784, 32, 2),
(98, 8764, 631, 8);

-- --------------------------------------------------------

--
-- Structure de la table `Equipage`
--

CREATE TABLE IF NOT EXISTS `Equipage` (
  `CrewTag` int(10) unsigned NOT NULL,
  `Effectif` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`CrewTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Equipage`
--

INSERT INTO `Equipage` (`CrewTag`, `Effectif`) VALUES
(45, 3),
(65, 86),
(156, 1),
(453, 2),
(543, 1),
(576, 38),
(785, 6),
(876, 38),
(78645, 700),
(84846, 4);

-- --------------------------------------------------------

--
-- Structure de la table `Soldat`
--

CREATE TABLE IF NOT EXISTS `Soldat` (
  `DogTag` int(10) unsigned NOT NULL,
  `Nom` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`DogTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Soldat`
--

INSERT INTO `Soldat` (`DogTag`, `Nom`) VALUES
(16, 'Sebastien Ducanon'),
(156, 'Henri Cochet'),
(315, 'Gilles Parbal'),
(456, 'Sandy Kilo'),
(516, 'Lara Masse'),
(876, 'Bernard Tichaut'),
(8764, 'Jean-Aymard'),
(9645, 'Otto Graf'),
(31245, 'Elie Coptér'),
(75645, 'Médhi Khaman');

-- --------------------------------------------------------

--
-- Structure de la table `soldatAppartient`
--

CREATE TABLE IF NOT EXISTS `soldatAppartient` (
  `DogTag` int(10) unsigned NOT NULL,
  `BatTag` int(10) unsigned NOT NULL,
  KEY `DogTag` (`DogTag`),
  KEY `BatTag` (`BatTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `soldatAppartient`
--

INSERT INTO `soldatAppartient` (`DogTag`, `BatTag`) VALUES
(31245, 8754),
(156, 784),
(876, 36),
(8764, 7845);

-- --------------------------------------------------------

--
-- Structure de la table `soldatEstMembreEquipage`
--

CREATE TABLE IF NOT EXISTS `soldatEstMembreEquipage` (
  `DogTag` int(10) unsigned NOT NULL,
  `CrewTag` int(10) unsigned NOT NULL,
  KEY `DogTag` (`DogTag`),
  KEY `CrewTag` (`CrewTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `soldatEstMembreEquipage`
--

INSERT INTO `soldatEstMembreEquipage` (`DogTag`, `CrewTag`) VALUES
(315, 45),
(516, 576),
(9645, 876);

-- --------------------------------------------------------

--
-- Structure de la table `Vehicule`
--

CREATE TABLE IF NOT EXISTS `Vehicule` (
  `VehTag` int(10) unsigned NOT NULL,
  `Sièges` int(10) unsigned DEFAULT NULL,
  `Reservoir` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`VehTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `Vehicule`
--

INSERT INTO `Vehicule` (`VehTag`, `Sièges`, `Reservoir`) VALUES
(4, 8, 100),
(13, 25, 0),
(87, 6, 68),
(156, 2, 0),
(543, 38, 37),
(645, 2, 100),
(786, 7, 100),
(4562, 5, 54),
(8765, 68, 100),
(45321, 12, 14);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `assigner`
--
ALTER TABLE `assigner`
  ADD CONSTRAINT `assigner_ibfk_2` FOREIGN KEY (`VehTag`) REFERENCES `Vehicule` (`VehTag`),
  ADD CONSTRAINT `assigner_ibfk_1` FOREIGN KEY (`CrewTag`) REFERENCES `Equipage` (`CrewTag`);

--
-- Contraintes pour la table `Bataillon`
--
ALTER TABLE `Bataillon`
  ADD CONSTRAINT `Bataillon_ibfk_1` FOREIGN KEY (`ComTag`) REFERENCES `Commandant` (`ComTag`);

--
-- Contraintes pour la table `engager`
--
ALTER TABLE `engager`
  ADD CONSTRAINT `engager_ibfk_2` FOREIGN KEY (`CampTag`) REFERENCES `Ennemis` (`CampTag`),
  ADD CONSTRAINT `engager_ibfk_1` FOREIGN KEY (`BatTag`) REFERENCES `Bataillon` (`BatTag`);

--
-- Contraintes pour la table `soldatAppartient`
--
ALTER TABLE `soldatAppartient`
  ADD CONSTRAINT `soldatAppartient_ibfk_2` FOREIGN KEY (`BatTag`) REFERENCES `Bataillon` (`BatTag`),
  ADD CONSTRAINT `soldatAppartient_ibfk_1` FOREIGN KEY (`DogTag`) REFERENCES `Soldat` (`DogTag`);

--
-- Contraintes pour la table `soldatEstMembreEquipage`
--
ALTER TABLE `soldatEstMembreEquipage`
  ADD CONSTRAINT `soldatEstMembreEquipage_ibfk_2` FOREIGN KEY (`CrewTag`) REFERENCES `Equipage` (`CrewTag`),
  ADD CONSTRAINT `soldatEstMembreEquipage_ibfk_1` FOREIGN KEY (`DogTag`) REFERENCES `Soldat` (`DogTag`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
