select VehTag, Reservoir from Vehicule where Reservoir<20;
select Nom,BatTag from Commandant natural join Bataillon;
select AVG(effectif) from Equipage;
select EffectifVehicule,count(EffectifVehicule) from Bataillon group by EffectifVehicule;
SELECT BatTag FROM engager WHERE NOT EXISTS (SELECT * FROM Ennemis WHERE engager.CampTag != 98 );