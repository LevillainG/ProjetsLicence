import java.io.*;
//TODO : Renseigner le champs auteur : Nom1_Prenom1_Nom2_Prenom2_Nom3_Prenom3
/**
 * 
 * @author Meslay_Fabrice_LeVilain_Gauthier_Picoreau_German
 * @version 2024
 *
 *
 *
 *	Compilation séparée 
 *	-> empiler les lignes "def" et "ref"
 *	-> remplir le descripteur au fur et à mesure
 *	-> marquer les emplacements des sauts/appels (faire des recherches systématiques)
 *
 *	modifVecteurTrans
 *
 */


class EltDicoDef {
	public String nomProc;
	public int adPo, nbParam;

	public EltDicoDef(String nomProc, int adPo, int nbParam) {
		this.nomProc= nomProc;
		this.adPo= adPo;
		this.nbParam = nbParam;

	}

}


public class Edl {

	// nombre max de modules, taille max d'un code objet d'une unite
	static final int MAXMOD = 5, MAXOBJ = 1000;
	// nombres max de references externes (REF) et de points d'entree (DEF)
	// pour une unite
	private static final int MAXREF = 10, MAXDEF = 10;

	// typologie des erreurs
	private static final int FATALE = 0, NONFATALE = 1;

	// valeurs possibles du vecteur de translation
	private static final int TRANSDON=1,TRANSCODE=2,REFEXT=3;

	// table de tous les descripteurs concernes par l'edl
	static Descripteur[] tabDesc = new Descripteur[MAXMOD + 1];

	//TODO : declarations de variables A COMPLETER SI BESOIN
	static int ipo, nMod, nbErr,it, ir;
	static String nomProg;
	static int[] transDon = new int[MAXMOD + 1];
	static int[] transCode = new int[MAXMOD + 1];
	static EltDicoDef[] dicoDef = new EltDicoDef[(MAXMOD+1)*MAXDEF] ;
	static int[][] adFinale = new int[MAXMOD][MAXREF+1];


	// utilitaire de traitement des erreurs
	// ------------------------------------
	static void erreur(int te, String m) {
		System.out.println(m);
		if (te == FATALE) {
			System.out.println("ABANDON DE L'EDITION DE LIENS");
			System.exit(1);
		}
		nbErr = nbErr + 1;
	}


	// utilitaire de remplissage de la table des descripteurs tabDesc
	// --------------------------------------------------------------
	static void lireDescripteurs() {
		String s;
		System.out.println("les noms doivent etre fournis sans suffixe");
		System.out.print("nom du programme : ");
		s = Lecture.lireString();
		tabDesc[0] = new Descripteur();
		tabDesc[0].lireDesc(s);
		if (!tabDesc[0].getUnite().equals("programme"))
			erreur(FATALE, "programme attendu");
		nomProg = s;

		nMod = 0;
		while (!s.equals("") && nMod < MAXMOD) {
			System.out.print("nom de module " + (nMod + 1)
					+ " (RC si termine) ");
			s = Lecture.lireString();
			if (!s.equals("")) {
				nMod = nMod + 1;
				tabDesc[nMod] = new Descripteur();
				tabDesc[nMod].lireDesc(s);

				if (!tabDesc[nMod].getUnite().equals("module"))
					erreur(FATALE, "module attendu");
			}
		}
	}


	static void constMap() {
		// f2 = fichier executable .map construit
		OutputStream f2 = Ecriture.ouvrir(nomProg + ".map");
		if (f2 == null)
			erreur(FATALE, "creation du fichier " + nomProg
					+ ".map impossible");
		// pour construire le code concatene de toutes les unités
		int[] po = new int[(nMod + 1) * MAXOBJ + 1];


		//TODO : ... A COMPLETER ...
		// 
		//

		Ecriture.fermer(f2);

		// creation du fichier en mnemonique correspondant
		Mnemo.creerFichier(ipo, po, nomProg + ".ima");
	}


	private static void placeDef(String nomProc, int adPo, int nbParam) {
		if (it == (MAXMOD+1)*MAXDEF)
			UtilLex.messErr("debordement de la table des symboles");
		it = it + 1;
		dicoDef[it] = new EltDicoDef(nomProc,adPo,nbParam);
	}


	private static int presentDef(int borneInf, String nom) {
		int i = it;
		while (i >= borneInf && !dicoDef[i].nomProc.equals(nom))
			i--;
		if (i >= borneInf)
			return i;
		else
			return 0;
	}


	public static void main(String argv[]) {
		System.out.println("EDITEUR DE LIENS / PROJET LICENCE");
		System.out.println("---------------------------------");
		System.out.println("");
		nbErr = 0;


		// Phase 1 de l'edition de liens 
		// -----------------------------
		lireDescripteurs();		//TODO : lecture des descripteurs a completer si besoin

		//TODO : ... A COMPLETER ...


		//Calcul des bases de décalage
		transDon[0] = 0;
		transCode[0] = 0;
		for(int i = 1; i<=nMod; i++) {
			transDon[i] = tabDesc[i-1].getTailleGlobaux()+ transDon[i-1];
			transCode[i] = tabDesc[i-1].getTailleCode() + transCode[i-1];

			//construction du dictionnaire DicoDef
			for(int j=1;j<=tabDesc[i].getNbDef();j++) {
				if(presentDef(1,tabDesc[i].getDefNomProc(j)) == 0) {
					placeDef(tabDesc[i].getDefNomProc(j),tabDesc[i].getDefAdPo(j)+transCode[i],
							tabDesc[i].getDefNbParam(j));
				}else {
					//ERREUR
					erreur(NONFATALE,"Def en doublon dans dicoDef");
				}
			}
		}
		
		//MAJ adFinale pour le prog
		for(int j =0;j<=tabDesc[0].getNbRef();j++) {
			if(presentDef(1,tabDesc[0].getRefNomProc(j))!=0)
			adFinale[0][j] = dicoDef[presentDef(1,tabDesc[0].getRefNomProc(j))].adPo;//adpo associé au nom de la ref
		}
		for(int i = 1; i<=nMod; i++) {
			for(int j =0;j<=tabDesc[0].getNbRef();j++) {
				if(presentDef(1,tabDesc[i].getRefNomProc(j))!=0)
				adFinale[i][j] = dicoDef[presentDef(1,tabDesc[i].getRefNomProc(j))].adPo;//adpo associé au nom de la ref
		}
	}
		
//		// affiche dicodef
//		for(int i = 0;i<dicoDef.length;i++) {
//			if(dicoDef[i]!=null) {
//			System.out.print(i+"nom :"+dicoDef[i].nomProc);System.out.print("   adpo : "+dicoDef[i].adPo);System.out.print("   nbParam : "+dicoDef[i].nbParam);
//			System.out.println();
//			}
//		}
//		//affiche adfinale
//		for(int i =0;i<MAXMOD;i++) {
//			System.out.println();
//			for(int j=1; j<MAXREF+1;j++) {
//				System.out.print(adFinale[i][j]+" ");
//			}
//		}


		if (nbErr > 0) {
			System.out.println("programme executable non produit");
			System.exit(1);
		}

		// Phase 2 de l'edition de liens
		// -----------------------------
		constMap();				//TODO : ... A COMPLETER ...
		System.out.println("Edition de liens terminee");
	}
}
