/*********************************************************************************
 * VARIABLES ET METHODES FOURNIES PAR LA CLASSE UtilLex (cf libClass_Projet)     *
 *       complement à l'ANALYSEUR LEXICAL produit par ANTLR                      *
 *                                                                               *
 *                                                                               *
 *   nom du programme compile, sans suffixe : String UtilLex.nomSource           *
 *   ------------------------                                                    *
 *                                                                               *
 *   attributs lexicaux (selon items figurant dans la grammaire):                *
 *   ------------------                                                          *
 *     int UtilLex.valEnt = valeur du dernier nombre entier lu (item nbentier)   *
 *     int UtilLex.numIdCourant = code du dernier identificateur lu (item ident) *
 *                                                                               *
 *                                                                               *
 *   methodes utiles :                                                           *
 *   ---------------                                                             *
 *     void UtilLex.messErr(String m)  affichage de m et arret compilation       *
 *     String UtilLex.chaineIdent(int numId) delivre l'ident de codage numId     *
 *     void afftabSymb()  affiche la table des symboles                          *
 *********************************************************************************/


import java.io.*;
import java.util.ArrayList;

import antlr.collections.List;

/**
 * classe de mise en oeuvre du compilateur
 * =======================================
 * (verifications semantiques + production du code objet)
 * 
 * @author Girard, Masson, Perraudeau
 *
 */

public class PtGen {


	// constantes manipulees par le compilateur
	// ----------------------------------------

	private static final int 

	// taille max de la table des symboles
	MAXSYMB=300,

	// codes MAPILE :
	RESERVER=1,EMPILER=2,CONTENUG=3,AFFECTERG=4,OU=5,ET=6,NON=7,INF=8,
	INFEG=9,SUP=10,SUPEG=11,EG=12,DIFF=13,ADD=14,SOUS=15,MUL=16,DIV=17,
	BSIFAUX=18,BINCOND=19,LIRENT=20,LIREBOOL=21,ECRENT=22,ECRBOOL=23,
	ARRET=24,EMPILERADG=25,EMPILERADL=26,CONTENUL=27,AFFECTERL=28,
	APPEL=29,RETOUR=30,

	// codes des valeurs vrai/faux
	VRAI=1, FAUX=0,

	// types permis :
	ENT=1,BOOL=2,NEUTRE=3,

	// categories possibles des identificateurs :
	CONSTANTE=1,VARGLOBALE=2,VARLOCALE=3,PARAMFIXE=4,PARAMMOD=5,PROC=6,
	DEF=7,REF=8,PRIVEE=9,

	//valeurs possible du vecteur de translation 
	TRANSDON=1,TRANSCODE=2,REFEXT=3;


	// utilitaires de controle de type
	// -------------------------------
	/**
	 * verification du type entier de l'expression en cours de compilation 
	 * (arret de la compilation sinon)
	 */
	private static void verifEnt() {
		if (tCour != ENT)
			UtilLex.messErr("expression entiere attendue");
	}
	/**
	 * verification du type booleen de l'expression en cours de compilation 
	 * (arret de la compilation sinon)
	 */
	private static void verifBool() {
		if (tCour != BOOL)
			UtilLex.messErr("expression booleenne attendue");
	}

	// pile pour gerer les chaines de reprise et les branchements en avant
	// -------------------------------------------------------------------

	private static TPileRep pileRep;  


	// production du code objet en memoire
	// -----------------------------------

	private static ProgObjet po;


	// COMPILATION SEPAREE 
	// -------------------
	//
	/** 
	 * modification du vecteur de translation associe au code produit 
	 * + incrementation attribut nbTransExt du descripteur
	 *  NB: effectue uniquement si c'est une reference externe ou si on compile un module
	 * @param valeur : TRANSDON, TRANSCODE ou REFEXT
	 */
	private static void modifVecteurTrans(int valeur) {
		if (valeur == REFEXT || desc.getUnite().equals("module")) {
			po.vecteurTrans(valeur);
			desc.incrNbTransExt();
		}
	}    
	// descripteur associe a un programme objet (compilation separee)
	private static Descripteur desc;


	// autres variables fournies
	// -------------------------

	// MERCI de renseigner ici un nom pour le trinome, constitue EXCLUSIVEMENT DE LETTRES
	public static String trinome="GFG"; //Gauthier Fabien German	

	private static int tCour; // type de l'expression compilee
	private static int tPrecedent; // Stockage du type de l'expression précédente
	private static int vCour; // sert uniquement lors de la compilation d'une valeur (entiere ou boolenne)
	private static int tmpInfo; // stocker temporairement l'info d'un ident
	private static int tmpCat;	// stocker temporairement la categorie d'un ident
	// TABLE DES SYMBOLES
	// ------------------
	//
	private static EltTabSymb[] tabSymb = new EltTabSymb[MAXSYMB + 1];

	// it = indice de remplissage de tabSymb
	// bc = bloc courant (=1 si le bloc courant est le programme principal)
	private static int it, bc;
	//Compteur variables
	private static int nbVarG;
	private static int nbVar;
	private static int nbParam;
	private static int nbRef;
	private static int adVar;
	private static int adParam;
	private static int i = 0;
	private static boolean loc;
	private static boolean isDef;
	private static String nomProc;
	private static boolean isMod;


	/** 
	 * utilitaire de recherche de l'ident courant (ayant pour code UtilLex.numIdCourant) dans tabSymb
	 * 
	 * @param borneInf : recherche de l'indice it vers borneInf (=1 si recherche dans tout tabSymb)
	 * @return : indice de l'ident courant (de code UtilLex.numIdCourant) dans tabSymb (O si absence)
	 */
	private static int presentIdent(int borneInf) {
		int i = it;
		while (i >= borneInf && tabSymb[i].code != UtilLex.numIdCourant)
			i--;
		if (i >= borneInf)
			return i;
		else
			return 0;
	}

	/**
	 * utilitaire de placement des caracteristiques d'un nouvel ident dans tabSymb
	 * 
	 * @param code : UtilLex.numIdCourant de l'ident
	 * @param cat : categorie de l'ident parmi CONSTANTE, VARGLOBALE, PROC, etc.
	 * @param type : ENT, BOOL ou NEUTRE
	 * @param info : valeur pour une constante, ad d'exécution pour une variable, etc.
	 */
	private static void placeIdent(int code, int cat, int type, int info) {
		if (it == MAXSYMB)
			UtilLex.messErr("debordement de la table des symboles");
		it = it + 1;
		tabSymb[it] = new EltTabSymb(code, cat, type, info);
	}

	/**
	 *  utilitaire d'affichage de la table des symboles
	 */
	private static void afftabSymb() { 
		System.out.println("       code           categorie      type    info");
		System.out.println("      |--------------|--------------|-------|----");
		for (int i = 1; i <= it; i++) {
			if (i == bc) {
				System.out.print("bc=");
				Ecriture.ecrireInt(i, 3);
			} else if (i == it) {
				System.out.print("it=");
				Ecriture.ecrireInt(i, 3);
			} else
				Ecriture.ecrireInt(i, 6);
			if (tabSymb[i] == null)
				System.out.println(" reference NULL");
			else
				System.out.println(" " + tabSymb[i]);
		}
		System.out.println();
	}


	/**
	 *  initialisations A COMPLETER SI BESOIN
	 *  -------------------------------------
	 */
	public static void initialisations() {

		// indices de gestion de la table des symboles
		it = 0;
		bc = 1;

		//Initialisation compteur variables
		nbVarG = 0;
		nbVar = 0;
		nbParam = 0;
		nbRef = 1;
		//bool local/global
		loc = false;

		// pile des reprises pour compilation des branchements en avant
		pileRep = new TPileRep(); 
		// programme objet = code Mapile de l'unite en cours de compilation
		po = new ProgObjet();
		// COMPILATION SEPAREE: desripteur de l'unite en cours de compilation
		desc = new Descripteur();

		// initialisation necessaire aux attributs lexicaux
		UtilLex.initialisation();

		// initialisation du type de l'expression courante
		tCour = NEUTRE;

		//TODO si necessaire

		isDef = false;
		
		tPrecedent = NEUTRE;
		

	} // initialisations

	public static void depilageBincond(int ipo) {
		if(ipo!=0) {
			int tmp = po.getElt(ipo);
			po.modifier(ipo, po.getIpo()+1);
			depilageBincond(tmp);
		}
	}
	
	public static void masquageParam() {
		for(int i = it; i>=bc;i--) {
			if(tabSymb[i].categorie == PARAMFIXE || tabSymb[i].categorie==PARAMMOD) {
				tabSymb[i].code = -1;
			}
		}
	}

	/**
	 *  code des points de generation A COMPLETER
	 *  -----------------------------------------
	 * @param numGen : numero du point de generation a executer
	 */
	public static void pt(int numGen) {

		switch (numGen) {
		case 0:
			initialisations();
			break;

		case 1: //ident
			if(presentIdent(1) != 0) {
				if(tabSymb[presentIdent(1)].categorie == VARGLOBALE) {
					po.produire(CONTENUG); 
					po.produire(tabSymb[presentIdent(1)].info);
					modifVecteurTrans(TRANSDON);
				}
				else if (tabSymb[presentIdent(1)].categorie == CONSTANTE) { 
					po.produire(EMPILER);
					po.produire(tabSymb[presentIdent(1)].info);
				} else if (tabSymb[presentIdent(bc)].categorie == VARLOCALE) { 
					po.produire(CONTENUL);
					po.produire(tabSymb[presentIdent(bc)].info);
					po.produire(0);
				} else if (tabSymb[presentIdent(bc)].categorie == PARAMFIXE) { 
					po.produire(CONTENUL);
					po.produire(tabSymb[presentIdent(bc)].info);
					po.produire(0);
				} else if (tabSymb[presentIdent(bc)].categorie == PARAMMOD) { 
					po.produire(CONTENUL);
					po.produire(tabSymb[presentIdent(bc)].info);
					po.produire(1);
				}
			} else {//Production variable locale en else
				System.out.println(po.getIpo());
				System.out.println("Variable ou constante non trouvée");
			}
			break;
		case 2: //valeur ent
			tCour = ENT;
			vCour = UtilLex.valEnt;
			break;
		case 3: //valeur bool vrai
			tCour = BOOL;
			vCour = VRAI;
			break;
		case 4: //consts
			if(presentIdent(bc) == 0) {
				placeIdent(UtilLex.numIdCourant, CONSTANTE, tCour, vCour);
			}
			break;
		case 5: //vars
			if(loc) {
				if(presentIdent(bc) == 0) {
					placeIdent(UtilLex.numIdCourant, VARLOCALE, tCour, adVar);
					nbVar++;
					adVar++;
				}
			} else {
				if(presentIdent(bc) == 0) {
					placeIdent(UtilLex.numIdCourant, VARGLOBALE, tCour, adVar);
					nbVarG++;
					nbVar++;
					adVar++;
				}
			}
			
			break;

		case 6: //valeur ent negatif
			tCour = ENT;
			vCour = UtilLex.valEnt * -1;
			break;

		case 7: //valeur bool faux
			tCour = BOOL;
			vCour = FAUX;
			break;

		case 8: //Type ent
			tCour = ENT;
			break;

		case 9: //Type bool
			tCour = BOOL;
			break;
			/* EXPRESSIONS */	

		case 10: //Ou
			po.produire(OU);
			break;

		case 11: //Et
			po.produire(ET);
			break;
		case 12: //Non
			po.produire(NON);
			break;
		case 13: //=
			po.produire(EG);
			break;
		case 14: //<>
			po.produire(DIFF);
			break;
		case 15: //>
			po.produire(SUP);
			break;
		case 16: //>=
			po.produire(SUPEG);
			break;
		case 17: //<
			po.produire(INF);
			break;
		case 18: //<=
			po.produire(INFEG);
			break;
		case 19: //+
			po.produire(ADD);
			break;
		case 20: //-
			po.produire(SOUS);
			break;
		case 21: //*
			po.produire(MUL);
			break;
		case 22: //div
			po.produire(DIV);
			break;
			
		case 23: // empiler une valeur
			po.produire(EMPILER);
			po.produire(vCour);
			break;
			
		case 24://reserver vars
			if(!isMod) {
			po.produire(RESERVER);
			po.produire(nbVar);
			}
			break;
			
		case 30: //mémorisation du type
			tPrecedent = tCour;
			break;
			
		case 31: //comparaison des types
			if(tPrecedent != tCour) {
				//	UtilLex.messErr("Type incorrect");
				System.out.println("erreur de type");
			}
			break;
			
		case 32:	//Comparaison des types Param
			tPrecedent = tabSymb[bc+i].type;
			i++;
			break;
			
		case 33:	// mise à jour tCour apres operateur de comparaison
			tCour = BOOL;
			break;
			
		case 34: // maj type pour expression avec un seul Ident
			tCour = tabSymb[presentIdent(1)].type;
			break;

		case 35://remise à 0*
			i=0;
			break;
			
			/* Affectations/Lecture/Ecriture*/
		case 40: //lecture
			if(tCour == ENT) {
				po.produire(LIRENT);
				if(tabSymb[presentIdent(bc)].categorie==VARLOCALE) {
					po.produire(AFFECTERL);
					po.produire(tabSymb[presentIdent(bc)].info);
				}else if(tabSymb[presentIdent(1)].categorie==VARGLOBALE) {
				po.produire(AFFECTERG);
				po.produire(tabSymb[presentIdent(1)].info);
				}
			} else if(tCour == BOOL) { 
				po.produire(LIREBOOL);
				if(tabSymb[presentIdent(bc)].categorie==VARLOCALE) {
					po.produire(AFFECTERL);
					po.produire(tabSymb[presentIdent(bc)].info);
				}else if(tabSymb[presentIdent(1)].categorie==VARGLOBALE) {
				po.produire(AFFECTERG);
				po.produire(tabSymb[presentIdent(1)].info);
				}
			}
			break;

		case 41: //ecriture
			if(tCour == ENT) {
				po.produire(ECRENT);

			} else if(tCour == BOOL) { 
				po.produire(ECRBOOL); 
			}
			break;


		case 43: //affouappe
			if((tmpCat == VARGLOBALE)){
			po.produire(AFFECTERG);
			po.produire(tmpInfo);

			} else if (tmpCat == VARLOCALE) { 
				po.produire(AFFECTERL);
				po.produire(tmpInfo);
				po.produire(0);

			} else if (tmpCat == PARAMMOD) { 
				po.produire(AFFECTERL);
				po.produire(tmpInfo);
				po.produire(1);

			} else if (tmpCat == PARAMFIXE) { 
				//ERROR
			} 
			break;

		case 44: // affectation
			//afftabSymb();
			
			if(presentIdent(bc)!=0) {
			tmpInfo = tabSymb[presentIdent(bc)].info;	//varLocale
			tmpCat = tabSymb[presentIdent(bc)].categorie;
			} else {				
				tmpInfo = tabSymb[presentIdent(1)].info; //VarGlobale
				tmpCat = tabSymb[presentIdent(1)].categorie;
			}
			break;
			/* Instructions */
		case 45: // appel: début de proc
			
			if(tabSymb[presentIdent(1)].categorie == PROC) {
			pileRep.empiler(tabSymb[presentIdent(1)].info);
			tmpInfo = tabSymb[presentIdent(1)+1].info;
			
			}
			break;
		case 46 : 
			po.produire(APPEL);
			po.produire(pileRep.depiler());
			modifVecteurTrans(TRANSCODE); 
			po.produire(tmpInfo);
			break;
		
		case 47: //effixe
			//po.produire(CONTENUL);
			//po.produire(tabSymb[presentIdent(bc)].info);
			break;
			
		case 48: // effmod
			if(tabSymb[presentIdent(1)].categorie==VARGLOBALE) {
			po.produire(EMPILERADG);
			po.produire(tabSymb[presentIdent(bc)].info);
			modifVecteurTrans(TRANSDON);
			} else if(tabSymb[presentIdent(bc)].categorie==VARLOCALE) {
				po.produire(EMPILERADL);
				po.produire(tabSymb[presentIdent(bc)].info);
				po.produire(0);
			} else if(tabSymb[presentIdent(bc)].categorie==PARAMMOD) {
				po.produire(EMPILERADL);
				po.produire(tabSymb[presentIdent(bc)].info);
				po.produire(1);
			}
			break;
			
			
		case 60: //Instruction

			break;
			
		case 61: //InstructionS

			break;
			
		case 62: //inssi
			po.produire(BSIFAUX);
			po.produire(-1);
			modifVecteurTrans(TRANSCODE);
			pileRep.empiler(po.getIpo());
			break;


		case 65: //sinon
			po.produire(BINCOND);
			po.produire(-1);
			modifVecteurTrans(TRANSCODE);
			po.modifier(pileRep.depiler(), po.getIpo()+1);//on donne l'info au bsifaux
			pileRep.empiler(po.getIpo());
			break;	

		case 66: //finsi
			po.modifier(pileRep.depiler(), po.getIpo()+1);
			break;	

		case 67: // début tant que
			pileRep.empiler(po.getIpo()+1);
			break;

		case 68: // fin tant que
			po.produire(BINCOND);
			po.modifier(pileRep.depiler(), po.getIpo()+2);
			po.produire(pileRep.depiler());
			modifVecteurTrans(TRANSCODE);
			break;

		case 69:
			po.produire(BINCOND);
			po.produire(0);
			modifVecteurTrans(TRANSCODE);
			po.modifier(pileRep.depiler(), po.getIpo()+1);
			pileRep.empiler(po.getIpo());
			break;

		/*case 70:
			aut =1;
			break;*/

		case 71:
			po.produire(BINCOND);
			po.modifier(pileRep.depiler(),po.getIpo()+2);
			po.produire(pileRep.depiler());
			modifVecteurTrans(TRANSCODE);
			pileRep.empiler(po.getIpo());
			break;

		case 72:
				depilageBincond(pileRep.depiler());
			break;
			
		case 73: //def?
			if(desc.presentDef(UtilLex.chaineIdent(UtilLex.numIdCourant)) > 0) {
				System.out.println(UtilLex.chaineIdent(UtilLex.numIdCourant));
				isDef = true;
				nomProc = UtilLex.chaineIdent(UtilLex.numIdCourant);
			}
			break;
			
		case 79: //màj nbparam
			tabSymb[bc - 1].info = nbParam;
			break;
			
		case 80: //def proc tabsymb
			placeIdent(UtilLex.numIdCourant, PROC, NEUTRE, po.getIpo()+1);
			placeIdent(-1, PRIVEE, NEUTRE,-1);
			bc = it + 1;
			break;

		case 81: //tabsymb.add parfixe
			placeIdent(UtilLex.numIdCourant, PARAMFIXE, tCour, adParam);

			nbParam++;
			adParam++;
			break;

		case 82: // parmod
			placeIdent(UtilLex.numIdCourant, PARAMMOD, tCour, adParam);
			nbParam++;
			adParam++;
			break;

		case 83: //  Bincond saut jusq'au main
			if(!isMod) {
			po.produire(BINCOND);
			po.produire(-1);
			modifVecteurTrans(TRANSCODE);
			pileRep.empiler(po.getIpo());
			}
			break;

		case 84: // set to local/set DEF
			if(isDef) {
				
				desc.modifDefNbParam(desc.presentDef(nomProc), nbParam);
				desc.modifDefAdPo(desc.presentDef(nomProc), tabSymb[bc-2].info);
				tabSymb[bc-1].categorie = DEF;
			}
			isDef = false;
			loc = true;
			adVar = adParam + 2;
			break;
			
		case 85: // retour
			po.produire(RETOUR);
			po.produire(nbParam);
			bc = 1;
			it = it - nbVar;
			masquageParam();
			break;
			
		case 86: // init proc
			nbParam = 0;
			nbVar = 0;
			adParam = 0;
			adVar = 0;
			break;
		
		case 87:
			if(!isMod)
			po.modifier(pileRep.depiler(), po.getIpo()+1);
			break;
			
			
		/** Partiedef / Partieref **/	
			
		case 90: //partieref
			placeIdent(UtilLex.numIdCourant, PROC, NEUTRE, nbRef);
			placeIdent(-1, REF, NEUTRE, nbParam);
			desc.ajoutRef(UtilLex.chaineIdent(UtilLex.numIdCourant)); //Remplissage du descripteur
			nomProc = UtilLex.chaineIdent(UtilLex.numIdCourant);
			nbRef++;
			nbParam = 0;
			break;
			
		case 91: //partiedef
			desc.ajoutDef(UtilLex.chaineIdent(UtilLex.numIdCourant)); //Remplissage du descripteur
			nomProc = UtilLex.chaineIdent(UtilLex.numIdCourant);
			break;
			
		case 92 ://addparam FIXE
			placeIdent(-1, PARAMFIXE, tCour, nbParam);
			nbParam++;
			break;
			
		case 93 ://addparam MOD
			placeIdent(-1, PARAMMOD, tCour, nbParam);
			nbParam++;
			break;	
		case 94: //maj nbParam
			desc.modifDefNbParam(desc.presentDef(nomProc), nbParam);
			break;
			
			case 95: // majnbParam REF
			desc.modifRefNbParam(desc.presentRef(nomProc), nbParam);
			break;
						
			
		case 252:// fin sans arret
			isMod = false;
			desc.setTailleCode(po.getIpo());
			desc.setTailleGlobaux(nbVarG);
			afftabSymb(); // affichage de la table des symboles en fin de compilation
			po.constGen();
			desc.ecrireDesc(UtilLex.nomSource);
		break;
			
		case 253:
			desc.setUnite("programme");
			break;
			
		case 254:
			desc.setUnite("module");
			isMod = true;
			break;
			
		case 255 : 
			po.produire(ARRET);
			desc.setTailleCode(po.getIpo());
			desc.setTailleGlobaux(nbVarG);
			afftabSymb(); // affichage de la table des symboles en fin de compilation
			po.constGen();
			desc.ecrireDesc(UtilLex.nomSource);
			break;


		default:
			System.out.println("Point de generation non prevu dans votre liste");
			System.out.println(po.getIpo());
			break;

		}
	}
}














