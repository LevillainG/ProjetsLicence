package fr.istic.cal.while1cons

import scala.util.Try

/**
 * définition d'une exception pour le cas des listes vides
 */
case object ExceptionListeVide extends Exception

/**
 * définition d'une exception pour le cas des listes de tailles différentes
 */
case object ExceptionListesDeLongueursDifferentes extends Exception

object While1cons {

  /**
   * UN ELIMINATEUR D'EXPRESSIONS COMPLEXES POUR LE LANGAGE WHILE
   *
   */

  /**
   *  TRAITEMENT DES EXPRESSIONS DU LANGAGE WHILE
   */

  /**
   * @param expression : un AST décrivant une expression du langage WHILE
   * @return une paire constituée d'une liste d'affectations ayant le même effet
   * que l'expression et de la variable qui contient le résultat
   */
  def while1ConsExprV(expression: Expression): (List[Command], Variable) = {
    expression match {
      case Nl => {
        val newVar = NewVar.make()
        (List(Set(newVar, Nl)), newVar)
      }
      case Cst(name: String) => {
        val newVar = NewVar.make()
        (List(Set(newVar, Cst(name))), newVar)
      }
      case VarExp(name: String) => {
        (List(), Var(name))
      }
      case Cons(arg1, arg2) => {
        val setArg1 = while1ConsExprV(arg1)
        val setArg2 = while1ConsExprV(arg2)
        val newVarX = NewVar.make()
        (setArg1, setArg2) match {
          case ((list1, Var(s1)), (list2, Var(s2))) => (list1 ++ list2 ++ List(Set(newVarX, Cons(VarExp(s1), VarExp(s2)))), newVarX)
        }
      }
      case Hd(arg) => {
        val setArg1 = while1ConsExprV(arg)
        val newVarX = NewVar.make()
        (setArg1) match {
          case (list1, Var(s1)) => (list1 ++ List(Set(newVarX, Hd(VarExp(s1)))), newVarX)
        }
      }
      case Tl(arg) => {
        val setArg1 = while1ConsExprV(arg)
        val newVarX = NewVar.make()
        (setArg1) match {
          case (list1, Var(s1)) => (list1 ++ List(Set(newVarX, Tl(VarExp(s1)))), newVarX)
        }
      }
      case Eq(arg1, arg2) => {
        val setArg1 = while1ConsExprV(arg1)
        val setArg2 = while1ConsExprV(arg2)
        val newVarX = NewVar.make()
        (setArg1, setArg2) match {
          case ((list1, Var(s1)), (list2, Var(s2))) => (list1 ++ list2 ++ List(Set(newVarX, Eq(VarExp(s1), VarExp(s2)))), newVarX)
        }
      }
    }
  }

  /**
   * @param expression : un AST décrivant une expression du langage WHILE
   * @return une paire constituée d'une liste d'affectations et une expression simple
   * qui, combinées, ont le même effet que l'expression initiale
   */
  // TODO TP4
  def while1ConsExprSE(expression: Expression): (List[Command], Expression) = {
    expression match {
      case Nl        => (Nil, Nl)
      case Cst(c)    => (Nil, Cst(c))
      case VarExp(v) => (Nil, VarExp(v))
      case Cons(arg1, arg2) => {
        (arg1, arg2) match {
          case (VarExp(x), VarExp(y)) =>
            (Nil, Cons(VarExp(x), VarExp(y)))
          case (VarExp(x), arg4) => {
            while1ConsExprV(arg4) match {
              case (l, Var(y)) => (l, Cons(VarExp(x), VarExp(y)))
            }
          }
          case (arg3, VarExp(y)) => {
            while1ConsExprV(arg3) match {
              case (l, Var(x)) => (l, Cons(VarExp(x), VarExp(y)))
            }
          }
          case _ =>
            (while1ConsExprV(arg1), while1ConsExprV(arg2)) match {
              case ((l1, Var(x)), (l2, Var(y))) => (l1 ++ l2, Cons(VarExp(x), VarExp(y)))
            }
        }
      }
      case Hd(arg) => {
        arg match {
          case VarExp(x) => (Nil, Hd(VarExp(x)))
          case _ =>
            while1ConsExprV(arg) match {
              case (l, Var(x)) => (l, Hd(VarExp(x)))
            }
        }
      }
      case Tl(arg) => {
        arg match {
          case VarExp(x) => (Nil, Tl(VarExp(x)))
          case _ =>
            while1ConsExprV(arg) match {
              case (l, Var(x)) => (l, Tl(VarExp(x)))
            }
        }
      }
      case Eq(arg1, arg2) => {
        (arg1, arg2) match {
          case (VarExp(x), VarExp(y)) =>
            (Nil, Eq(VarExp(x), VarExp(y)))
          case (VarExp(x), arg4) => {
            while1ConsExprV(arg4) match {
              case (l, Var(y)) => (l, Eq(VarExp(x), VarExp(y)))
            }
          }
          case (arg3, VarExp(y)) => {
            while1ConsExprV(arg3) match {
              case (l, Var(x)) => (l, Eq(VarExp(x), VarExp(y)))
            }
          }
          case _ =>
            (while1ConsExprV(arg1), while1ConsExprV(arg2)) match {
              case ((l1, Var(x)), (l2, Var(y))) => (l1 ++ l2, Eq(VarExp(x), VarExp(y)))
            }
        }
      }
    }
  }

  /**
   *
   *  TRAITEMENT DES COMMANDES DU LANGAGE WHILE
   */
  /**
   * @param command : un AST décrivant une commande du langage WHILE
   * @return une liste de commandes ayant un seul constructeur par expression
   * et ayant le même effet que la commande initiale
   */
  // TODO TP4
  def while1ConsCommand(command: Command): List[Command] = {
    command match {
      case Nop => List(Nop)
      case Set(variable, expression) => {
        while1ConsExprSE(expression) match {
          case (Nil, se) => List(Set(variable, se))
          case (l, se)   => while1ConsCommands(l) ++ List(Set(variable, se))
        }
      }
      case While(condition, body) => {
        while1ConsExprV(condition) match {
          case (l, Var(x)) => l ++ List(While(VarExp(x), while1ConsCommands(body) ++ l))
        }
      }
      case For(count, body) => {
        while1ConsExprV(count) match {
          case (l, Var(x)) => l ++ List(For(VarExp(x), while1ConsCommands(body)))
        }
      }
      case If(condition, then_commands, else_commands) => {
        while1ConsExprV(condition) match {
          case (l, Var(x)) => l ++ List(If(VarExp(x), while1ConsCommands(then_commands), while1ConsCommands(else_commands)))
        }
      }
    }
  }

  /**
   * @param commands : une liste non vide d'AST décrivant une liste non vide de commandes du langage WHILE
   * @return une liste de commandes ayant un seul constructeur par expression
   * et ayant le même effet que les commandes initiales
   */
  // TODO TP4
  def while1ConsCommands(commands: List[Command]): List[Command] = {
    commands match {
      case command :: Nil => while1ConsCommand(command)
      case command :: reste => {
        while1ConsCommand(command) ++ while1ConsCommands(reste)
      }
    }
  }

  /**
   *
   *  TRAITEMENT DES PROGRAMMES DU LANGAGE WHILE
   */

  /**
   * @param program : un AST décrivant un programme du langage WHILE
   * @return un AST décrivant un programme du langage WHILE
   * de même sémantique que le programme initial mais ne contenant que des expressions simples
   */
  // TODO TP4
  def while1ConsProgr(program: Program): Program = {
    program match {
      case Progr(in,body,out) => Progr(in,while1ConsCommands(body),out)
    }
  }

  def main(args: Array[String]): Unit = {

    // vous pouvez ici tester manuellement vos fonctions par des print

  }

  /**
   * UTILISATION D'UN ANALYSEUR SYNTAXIQUE POUR LE LANGAGE WHILE
   *
   * les 3 fonctions suivantes permettent de construire un arbre de syntaxe abstraite
   * respectivement pour une expression, une commande, un programme
   */

  /**
   * @param s : une chaine de caractères représentant la syntaxe concrète d'une expression du langage WHILE
   * @return un arbre de syntaxe abstraite pour cette expression
   */
  def readWhileExpression(s: String): Expression = { WhileParser.analyserexpression(s) }

  /**
   * @param s : une chaine de caractères représentant la syntaxe concrète d'une commande du langage WHILE
   * @return un arbre de syntaxe abstraite pour cette commande
   */
  def readWhileCommand(s: String): Command = { WhileParser.analysercommand(s) }

  /**
   * @param s : une chaine de caractères représentant la syntaxe concrète d'un programme du langage WHILE
   * @return un arbre de syntaxe abstraite pour ce programme
   */
  def readWhileProgram(s: String): Program = { WhileParser.analyserprogram(s) }

}